# Message Vault – Deleted Message Recovery

A private Android app that keeps a local copy of the WhatsApp messages and media your phone receives. If a sender later uses "Delete for everyone", you can still read the copy inside Message Vault.

It uses **only official Android APIs and permissions you grant**:

- `NotificationListenerService` for message text
- Storage Access Framework / MediaStore for media files

WhatsApp is never modified, injected into or read directly. The app has **no internet permission**, so nothing can leave the phone.

---

## 1. What it can and cannot do (please read)

| Can do | Cannot do (Android/WhatsApp do not allow it) |
|---|---|
| Save message text, sender, group, time **the moment the notification arrives** | Capture messages that never produced a notification (chat open on screen, muted chat, notifications off) |
| Detect deletion when WhatsApp re-posts the notification as *"This message was deleted"* (**confirmed**) | Detect every deletion. WhatsApp often just removes the notification, which looks the same as "read on another device" |
| Flag messages that vanish from a live notification while newer ones stay (**possibly deleted**) | Read WhatsApp's encrypted database or messages from before installation |
| Copy photos, videos, voice notes, audio, documents, GIFs and stickers **that WhatsApp downloaded** | Recover media that was never downloaded (auto-download off), or view-once media |
| Save the reduced preview image WhatsApp puts in a photo notification | Show more text than WhatsApp put in the notification (long texts may be cut) |
| Link media to messages by type + time (and by file name for documents) | Guarantee perfect media-to-message matching in very busy chats |
| Show the phone number when WhatsApp exposes it (e.g. unsaved contacts) | Show numbers WhatsApp hides (saved contacts, newer privacy IDs) |

The app never shows fake "recovered" data. Every limitation is shown inside the app (About screen, empty states, message details).

---

## 2. Architecture

```
┌────────────────────────── Android system ──────────────────────────┐
│  WhatsApp posts notification ──► NotificationListenerService       │
└───────────────────────────────────────┬────────────────────────────┘
                                        ▼
 capture/VaultNotificationListener ── WhatsAppNotificationParser (MessagingStyle → messages)
        │  store immediately                │ deletion indicators ("This message was deleted",
        ▼                                   │  vanished-from-notification detection)
 data/repo/CaptureRepository ──► Room (encrypted text via FieldCipher / Android Keystore)
        │ media message seen
        ▼
 work/MediaScanWorker (WorkManager: +20 s, +2 min, every 15 min)
        ▼
 media/WhatsAppMediaScanner (SAF tree + optional MediaStore) ──► MediaImporter
        (SHA-256 de-dup, copy to filesDir/vault_media, link to nearest message)

 UI: Jetpack Compose + Material 3 ─ ViewModels ─ ArchiveRepository (decrypt → UI models)
 Backup: BackupManager (zip + AES-256-GCM, PBKDF2 password) via Storage Access Framework
```

**Room entities** (`data/db/Entities.kt`):

- `ArchivedMessage`: has a foreign key to `ContactInfo`, and the message text is encrypted.
- `ArchivedMedia`: has a foreign key to `ArchivedMessage` with cascade delete, plus a unique SHA-256 hash.
- `ContactInfo`
- `CaptureSettings`: a single-row table.
- Relation: `MessageWithMedia`.

**Security:**

- **Message text:** encrypted with AES-256-GCM using a data key. That key is wrapped by a non-exportable Android Keystore key.
- **App lock:** a PIN, stored as a PBKDF2 hash, with optional biometric unlock through `BiometricPrompt`.
- **Screenshots:** `FLAG_SECURE` is on by default.
- **Backups:** Android cloud backup and device transfer are excluded.
- **Internet:** the `INTERNET` permission is explicitly removed from the manifest.

---

## 3. Project structure

```
MessageVault/
├── build.gradle.kts, settings.gradle.kts, gradle.properties, gradlew(.bat), gradle/wrapper/
└── app/
    ├── build.gradle.kts, proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/ (theme, colors, adaptive app icon, FileProvider paths, backup exclusion rules)
        └── java/com/messagevault/app/
            ├── MessageVaultApp.kt          Application, Coil image loader, WorkManager schedule
            ├── AppContainer.kt             Dependency container
            ├── MainActivity.kt             Splash, edge-to-edge, app lock, FLAG_SECURE
            ├── capture/                    NotificationListenerService + WhatsApp parser
            ├── data/model/Enums.kt         Categories, media types, recovery status
            ├── data/db/                    Room entities, DAOs, converters, database
            ├── data/repo/                  Capture, archive (queries/cleanup), settings
            ├── media/                      SAF/MediaStore scanner, importer (de-dup, linking)
            ├── backup/BackupManager.kt     Encrypted backup / restore
            ├── security/                   Keystore field encryption, PIN hashing
            ├── work/Workers.kt             Media scan + cleanup workers, scheduler
            ├── util/                       System status/intents, formatting, file opening
            └── ui/
                ├── theme/  components/  viewmodel/  navigation/
                └── screens/                All screens (see below)
```

**Screens:**

1. Splash
2. Welcome
3. Permission setup
4. Notification access instructions
5. Dashboard
6. All messages
7. Deleted archive
8. Images (and GIFs)
9. Videos
10. Audio
11. Voice notes
12. Stickers
13. Documents
14. Message details
15. Search (filters for contact, date, content type, deleted-only)
16. Storage management (usage, media folder, cleanup, limit, backup/restore, clear archive)
17. Privacy & security
18. Settings
19. About

There are also a media viewer (zoomable images, video player, audio player, document opener) and a lock screen.

**Stack:**

- Kotlin 2.0, AGP 8.7, Gradle 8.11
- Jetpack Compose (BOM 2024.12) with Material 3
- Room 2.6 (KSP), Coroutines/Flow, WorkManager 2.10
- Biometric 1.1, Coil 2.7 (with GIF and video frames)
- minSdk 29 (Android 10), targetSdk 35 (Android 15)

---

## 4. Build the APK

### Option A: Android Studio (recommended)

1. Install **Android Studio** (Ladybug 2024.2 or newer). On first start, let it install the Android SDK (API 35).
2. **File → Open** and choose the `MessageVault` folder. Wait for "Gradle sync" to finish. The first sync downloads dependencies and needs internet on your PC.
3. Pick a build:
   - Debug APK: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. You get `app/build/outputs/apk/debug/app-debug.apk`, and the app installs as "Message Vault" with package `com.messagevault.app.debug`.
   - Release APK (smaller and faster): open the **Build Variants** panel, choose `release`, then build again. You get `app/build/outputs/apk/release/app-release.apk`.

   The release build is signed with your local debug key so it installs directly. Use your own keystore if you ever distribute it.

### Option B: command line

```bash
cd MessageVault
# Requires JDK 17+ and ANDROID_HOME (or local.properties with sdk.dir=...)
./gradlew assembleRelease        # or assembleDebug
```

Windows: `gradlew.bat assembleRelease`

---

## 5. Install on Xiaomi Redmi 14C 5G (HyperOS / Android 14)

1. **Copy the APK** to the phone (USB, Google Drive, etc.) and tap it in **Files**. Allow "Install unknown apps" for the Files app when asked. HyperOS may show a security scan; choose **Install anyway**.

   With USB debugging you can instead run `adb install -r app-release.apk`. To get USB debugging: Settings → About phone → tap **OS version** 7 times, then Settings → Additional settings → Developer options → **USB debugging** (and **Install via USB**).
2. **Open Message Vault** and follow the setup screens.
3. **Allow restricted settings.** This is required for APKs installed from a file on Android 13 and newer. If the notification-access switch is greyed out:

   Settings → Apps → Manage apps → Message Vault → ⋮ (top-right) → **Allow restricted settings** → confirm.
4. **Notification access:** Settings → Notifications & status bar → Notification access (or use the button in the app) → enable **Message Vault**.
5. **Keep it running on HyperOS:** Settings → Apps → Manage apps → Message Vault:
   - **Battery saver → No restrictions**
   - **Autostart → On**
   - Optionally lock the app in Recents: open recents and swipe down on its card.
6. **WhatsApp settings:**
   - WhatsApp → Settings → Notifications: keep message notifications on.
   - Keep auto-download on (Settings → Storage and data → Media auto-download) for the media types you want archived.
7. **Media folder:** in Message Vault go to Permission setup → **Choose folder**. Navigate to `Android/media/com.whatsapp/WhatsApp/Media` and tap **Use this folder → Allow**.

---

## 6. Test checklist

| # | Scenario | Steps | Expected result |
|---|---|---|---|
| 1 | Receive text | From a second phone, send a WhatsApp text. Keep the chat closed on the test phone. | The notification appears. |
| 2 | Capture | Open Message Vault → Dashboard → Recently captured. | The message is shown with sender and time. |
| 3 | Delete for everyone | On the sender phone, long-press the message → Delete for everyone. | WhatsApp may update or remove its notification. |
| 4–5 | Check vault | Open Message Vault. | The original text is still in **All messages**. If WhatsApp posted "This message was deleted", it also appears in **Deleted archive** as *Deleted by sender*. If the notification was only removed, it stays in All messages, and you can tap **Mark as deleted**. |
| 6 | Media | Send an image, video, voice note, audio and PDF. Wait 1–2 minutes (or Storage → **Scan now**), then delete them for everyone. | Files WhatsApp downloaded show up in their archives, linked to the message. A photo notification preview is saved instantly. Files that were not downloaded show *"original file is not in the archive"*. |
| 7 | Group | Send a message in a group. | It shows *Sender · Group name*, and Details shows "Group · name". |
| 8 | App restart | Force-stop Message Vault, send a message, then open the app. | Android re-binds the listener and the message is captured. Already-visible notifications are captured when the listener reconnects. |
| 9 | Phone restart | Reboot, unlock, send a message. | It is captured, provided Autostart and battery are set as in step 5 of the install guide. |
| 10 | Missing permission | Turn off notification access. | The Dashboard shows a red **Capture is off** card with a fix button. |
| 11 | WhatsApp notifications off or previews hidden | Disable WhatsApp notifications, or hide previews. | With hidden previews, the dashboard warns "WhatsApp is hiding message previews". When nothing arrives for days, it warns "No WhatsApp notifications seen recently". Android does not let apps read another app's notification settings directly, so this is detected heuristically. |
| 12 | Unavailable media | Turn off auto-download, receive a photo, delete it. | The message shows the category and the clear "not available / never downloaded" notice. Nothing is faked. |

Debug logs: `adb logcat -s VaultListener MediaScanWorker MediaScanner CaptureRepository`

---

## 7. Troubleshooting

- **The notification-access switch is grey.** Allow restricted settings (install step 3).
- **Nothing is captured.**
  - Is the WhatsApp chat open on screen? WhatsApp doesn't notify for an open chat.
  - Is the chat muted?
  - Are previews hidden?
  - Is the Dashboard status green?
- **Capture stops after a while (Xiaomi).** Set Battery to No restrictions, turn Autostart on, lock the app in Recents. Then open the Notification access guide and tap **Restart listener**.
- **No media.** Check that the folder is connected (Storage screen), that auto-download is on in WhatsApp, and tap **Scan now**.
- **"Access lost" for the folder.** Choose the folder again. This happens if WhatsApp was reinstalled or storage was reset.
- **Backup restore says wrong password.** The password can't be recovered. Backups are encrypted with AES-256-GCM.

---

## 8. Privacy & responsibility

All data stays on the device. Uninstalling the app deletes the archive and its encryption key. Archived messages were written by other people, so respect their privacy and your local laws.

Message Vault is not affiliated with WhatsApp or Meta.
