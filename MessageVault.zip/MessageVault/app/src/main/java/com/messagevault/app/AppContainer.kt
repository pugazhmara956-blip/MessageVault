package com.messagevault.app

import android.content.Context
import com.messagevault.app.backup.BackupManager
import com.messagevault.app.data.db.VaultDatabase
import com.messagevault.app.data.repo.ArchiveRepository
import com.messagevault.app.data.repo.CaptureRepository
import com.messagevault.app.data.repo.SettingsRepository
import com.messagevault.app.media.MediaImporter
import com.messagevault.app.media.WhatsAppMediaScanner
import com.messagevault.app.security.FieldCipher
import com.messagevault.app.security.PinManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Simple manual dependency container (one instance per process). */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: VaultDatabase = VaultDatabase.build(appContext)
    val cipher = FieldCipher(appContext)
    val pinManager = PinManager()

    val settingsRepository = SettingsRepository(database.settingsDao())
    val mediaImporter = MediaImporter(appContext, database, settingsRepository)
    val captureRepository = CaptureRepository(appContext, database, cipher, mediaImporter)
    val archiveRepository = ArchiveRepository(appContext, database, cipher, mediaImporter)
    val mediaScanner = WhatsAppMediaScanner(appContext, mediaImporter)
    val backupManager = BackupManager(appContext, database, cipher, mediaImporter)
}
