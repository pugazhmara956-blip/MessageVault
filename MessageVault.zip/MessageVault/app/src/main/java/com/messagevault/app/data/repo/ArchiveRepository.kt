package com.messagevault.app.data.repo

import android.content.Context
import com.messagevault.app.data.db.ArchivedMedia
import com.messagevault.app.data.db.CaptureSettings
import com.messagevault.app.data.db.MessageWithMedia
import com.messagevault.app.data.db.VaultDatabase
import com.messagevault.app.data.model.MediaArchiveKind
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.MessageFilter
import com.messagevault.app.data.model.RecoveryStatus
import com.messagevault.app.media.MediaImporter
import com.messagevault.app.security.FieldCipher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

/** UI model of an archived media file. */
data class MediaItem(
    val id: Long,
    val messageId: Long?,
    val type: MediaType,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val file: File,
    val available: Boolean,
    val origin: MediaOrigin,
    val capturedAt: Long,
    val sourceTimestamp: Long
)

/** UI model of an archived message with decrypted text. */
data class MessageItem(
    val id: Long,
    val packageName: String,
    val conversationTitle: String,
    val isGroup: Boolean,
    val senderName: String,
    val senderPhone: String?,
    val text: String,
    val category: MessageCategory,
    val attachmentHint: String?,
    val originalTimestamp: Long,
    val capturedAt: Long,
    val status: RecoveryStatus,
    val statusChangedAt: Long?,
    val notificationKey: String?,
    val channelId: String?,
    val media: List<MediaItem>
) {
    val isBusiness: Boolean get() = packageName == "com.whatsapp.w4b"
    val expectsMedia: Boolean get() = category.mediaType != null
    /** True when a real file (not only a notification preview) is linked. */
    val hasOriginalMedia: Boolean get() = media.any { it.origin != MediaOrigin.NOTIFICATION_PREVIEW && it.available }
}

data class ArchiveCounts(
    val totalMessages: Int = 0,
    val deletedMessages: Int = 0,
    val totalMedia: Int = 0,
    val byCategory: Map<MessageCategory, Int> = emptyMap(),
    val mediaByType: Map<MediaType, Int> = emptyMap(),
    val mediaBytes: Long = 0
) {
    fun mediaCount(kind: MediaArchiveKind) = kind.types.sumOf { mediaByType[it] ?: 0 }
}

class ArchiveRepository(
    private val context: Context,
    private val db: VaultDatabase,
    private val cipher: FieldCipher,
    private val importer: MediaImporter
) {

    fun observeMessages(filter: MessageFilter): Flow<List<MessageItem>> = when (filter) {
        MessageFilter.ALL -> db.messageDao().observeAll()
        MessageFilter.DELETED -> db.messageDao().observeDeleted()
        MessageFilter.TEXT -> db.messageDao().observeByCategory(MessageCategory.TEXT)
    }.map { list -> list.map { it.toItem() } }.flowOn(Dispatchers.Default)

    fun observeAllMessages(): Flow<List<MessageItem>> = observeMessages(MessageFilter.ALL)

    fun observeRecent(limit: Int): Flow<List<MessageItem>> =
        db.messageDao().observeRecent(limit).map { l -> l.map { it.toItem() } }.flowOn(Dispatchers.Default)

    fun observeMessage(id: Long): Flow<MessageItem?> =
        db.messageDao().observeById(id).map { it?.toItem() }.flowOn(Dispatchers.Default)

    fun observeMedia(kind: MediaArchiveKind): Flow<List<MediaItem>> =
        db.mediaDao().observeByTypes(kind.types).map { l -> l.map { it.toItem() } }.flowOn(Dispatchers.IO)

    fun observeMediaItem(id: Long): Flow<MediaItem?> =
        db.mediaDao().observeById(id).map { it?.toItem() }.flowOn(Dispatchers.IO)

    fun observeSenders(): Flow<List<String>> = db.messageDao().observeSenders()

    fun observeCounts(): Flow<ArchiveCounts> = combine(
        db.messageDao().observeCount(),
        db.messageDao().observeDeletedCount(),
        db.messageDao().observeCategoryCounts(),
        db.mediaDao().observeCount(),
        db.mediaDao().observeStats()
    ) { total, deleted, categories, mediaTotal, stats ->
        ArchiveCounts(
            totalMessages = total,
            deletedMessages = deleted,
            totalMedia = mediaTotal,
            byCategory = categories.associate { it.category to it.count },
            mediaByType = stats.associate { it.type to it.count },
            mediaBytes = stats.sumOf { it.bytes }
        )
    }

    suspend fun setMarkedDeleted(id: Long, marked: Boolean) = withContext(Dispatchers.IO) {
        val msg = db.messageDao().getById(id) ?: return@withContext
        val newStatus = when {
            marked && msg.status == RecoveryStatus.CAPTURED -> RecoveryStatus.MARKED_DELETED
            !marked && msg.status == RecoveryStatus.MARKED_DELETED -> RecoveryStatus.CAPTURED
            else -> return@withContext
        }
        db.messageDao().updateStatus(id, newStatus, if (newStatus == RecoveryStatus.CAPTURED) null else System.currentTimeMillis())
    }

    suspend fun deleteMessage(id: Long) = withContext(Dispatchers.IO) {
        db.mediaDao().forMessage(id).forEach { importer.deleteFile(it) }
        db.messageDao().deleteById(id) // media rows cascade
        db.contactDao().deleteOrphans()
    }

    suspend fun deleteMedia(id: Long) = withContext(Dispatchers.IO) {
        val media = db.mediaDao().getById(id) ?: return@withContext
        importer.deleteFile(media)
        db.mediaDao().deleteById(id)
    }

    suspend fun clearArchive() = withContext(Dispatchers.IO) {
        db.mediaDao().deleteAll()
        db.messageDao().deleteAll()
        db.contactDao().deleteAll()
        importer.clearAllFiles()
    }

    /** Automatic cleanup by age, then enforce the storage limit (oldest media first). */
    suspend fun runMaintenance(settings: CaptureSettings) = withContext(Dispatchers.IO) {
        if (settings.autoCleanupDays > 0) {
            val cutoff = System.currentTimeMillis() - settings.autoCleanupDays * 24L * 60 * 60 * 1000
            db.messageDao().idsCapturedBefore(cutoff).forEach { deleteMessage(it) }
            db.mediaDao().capturedBefore(cutoff).forEach { deleteMedia(it.id) }
        }
        if (settings.storageLimitMb > 0) {
            val limit = settings.storageLimitMb * 1024L * 1024L
            var used = db.mediaDao().totalBytes()
            if (used > limit) {
                for (m in db.mediaDao().getAllOldestFirst()) {
                    if (used <= limit) break
                    deleteMedia(m.id)
                    used -= m.sizeBytes
                }
            }
        }
        db.contactDao().deleteOrphans()
        // Remove temp files left by interrupted imports.
        File(importer.mediaRoot, ".tmp").listFiles()?.forEach { it.delete() }
    }

    data class StorageInfo(val mediaBytes: Long, val databaseBytes: Long)

    suspend fun storageInfo(): StorageInfo = withContext(Dispatchers.IO) {
        val dbFile = context.getDatabasePath(VaultDatabase.NAME)
        val dbBytes = listOf(dbFile, File(dbFile.path + "-wal"), File(dbFile.path + "-shm"))
            .filter { it.exists() }.sumOf { it.length() }
        StorageInfo(importer.usedBytes(), dbBytes)
    }

    private fun MessageWithMedia.toItem(): MessageItem = MessageItem(
        id = message.id,
        packageName = message.packageName,
        conversationTitle = message.conversationTitle,
        isGroup = message.isGroup,
        senderName = message.senderName,
        senderPhone = message.senderPhone,
        text = cipher.decrypt(message.encryptedText),
        category = message.category,
        attachmentHint = message.attachmentHint,
        originalTimestamp = message.originalTimestamp,
        capturedAt = message.capturedAt,
        status = message.status,
        statusChangedAt = message.statusChangedAt,
        notificationKey = message.notificationKey,
        channelId = message.channelId,
        media = media.sortedBy { it.origin == MediaOrigin.NOTIFICATION_PREVIEW }.map { it.toItem() }
    )

    private fun ArchivedMedia.toItem(): MediaItem {
        val f = File(localPath)
        return MediaItem(
            id = id,
            messageId = messageId,
            type = mediaType,
            fileName = fileName,
            mimeType = mimeType,
            sizeBytes = sizeBytes,
            file = f,
            available = f.exists() && f.length() > 0,
            origin = origin,
            capturedAt = capturedAt,
            sourceTimestamp = sourceLastModified
        )
    }
}
