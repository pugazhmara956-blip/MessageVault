package com.messagevault.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        ArchivedMessage::class,
        ArchivedMedia::class,
        ContactInfo::class,
        CaptureSettings::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun mediaDao(): MediaDao
    abstract fun contactDao(): ContactDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        const val NAME = "message_vault.db"

        fun build(context: Context): VaultDatabase =
            Room.databaseBuilder(context.applicationContext, VaultDatabase::class.java, NAME)
                .build()
    }
}
