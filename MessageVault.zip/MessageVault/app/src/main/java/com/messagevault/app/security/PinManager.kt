package com.messagevault.app.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** PIN hashing with PBKDF2-HMAC-SHA256. The PIN itself is never stored. */
class PinManager {

    data class PinRecord(val hash: String, val salt: String)

    fun create(pin: String): PinRecord {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return PinRecord(
            hash = Base64.encodeToString(derive(pin, salt), Base64.NO_WRAP),
            salt = Base64.encodeToString(salt, Base64.NO_WRAP)
        )
    }

    fun verify(pin: String, hash: String?, salt: String?): Boolean {
        if (hash == null || salt == null) return false
        return try {
            val expected = Base64.decode(hash, Base64.NO_WRAP)
            val actual = derive(pin, Base64.decode(salt, Base64.NO_WRAP))
            MessageDigest.isEqual(expected, actual)
        } catch (e: Exception) {
            false
        }
    }

    fun isValidPin(pin: String): Boolean = pin.length in 4..8 && pin.all { it.isDigit() }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private companion object {
        const val ITERATIONS = 120_000
    }
}
