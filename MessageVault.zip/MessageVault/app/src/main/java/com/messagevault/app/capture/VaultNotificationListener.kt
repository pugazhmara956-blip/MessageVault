package com.messagevault.app.capture

import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.messagevault.app.MessageVaultApp
import com.messagevault.app.data.model.RecoveryStatus
import com.messagevault.app.work.WorkScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

/**
 * Receives WhatsApp notifications through Android's official NotificationListenerService.
 *
 * Content is saved the moment a notification is posted — the app does NOT depend on receiving
 * any deletion signal. Deletion is flagged only when WhatsApp exposes an indicator:
 *  - CONFIRMED: WhatsApp re-posts the notification with "This message was deleted".
 *  - SUSPECTED: a message vanishes from the live notification while newer messages remain.
 *
 * This service never posts notifications of its own and never draws over other apps.
 */
class VaultNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    private data class SnapshotEntry(val dedupeKey: String, val sender: String, val timestamp: Long)

    /** Last seen message list per notification key, used for vanish detection. */
    private val snapshots = ConcurrentHashMap<String, List<SnapshotEntry>>()
    private var lastStatusWrite = 0L

    private val container get() = (application as MessageVaultApp).container

    override fun onListenerConnected() {
        super.onListenerConnected()
        _connected.value = true
        scope.launch {
            runCatching {
                container.settingsRepository.update { it.copy(lastListenerConnectedAt = System.currentTimeMillis()) }
            }
            // Capture anything already in the shade (e.g. after a phone restart).
            val active = runCatching { activeNotifications?.toList() }.getOrNull().orEmpty()
            active.filter { it.packageName in WHATSAPP_PACKAGES }.forEach { sbn ->
                mutex.withLock { handle(sbn) }
            }
        }
    }

    override fun onListenerDisconnected() {
        _connected.value = false
        super.onListenerDisconnected()
        // Ask Android to bind us again (helps on aggressive OEM builds such as MIUI/HyperOS).
        runCatching { NotificationListenerService.requestRebind(ComponentName(this, VaultNotificationListener::class.java)) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in WHATSAPP_PACKAGES) return
        scope.launch { mutex.withLock { handle(sbn) } }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in WHATSAPP_PACKAGES) return
        // A removed notification is ambiguous (read, dismissed, opened, or deleted). Already-saved
        // content stays in the archive; we only forget the live snapshot.
        snapshots.remove(sbn.key)
    }

    override fun onDestroy() {
        _connected.value = false
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun handle(sbn: StatusBarNotification) {
        try {
            val settingsRepo = container.settingsRepository
            val settings = settingsRepo.current()
            if (!settings.backgroundCaptureEnabled) return
            if (sbn.packageName == PKG_WHATSAPP && !settings.whatsappCaptureEnabled) return
            if (sbn.packageName == PKG_WHATSAPP_BUSINESS && !settings.whatsappBusinessCaptureEnabled) return

            val parsed = WhatsAppNotificationParser.parse(this, sbn) ?: return

            val now = System.currentTimeMillis()
            if (now - lastStatusWrite > 60_000L || parsed.previewHidden) {
                lastStatusWrite = now
                settingsRepo.update {
                    it.copy(
                        lastWhatsAppNotificationAt = now,
                        previewHiddenDetectedAt = if (parsed.previewHidden) now else it.previewHiddenDetectedAt
                    )
                }
            }
            if (parsed.messages.isEmpty()) return

            val capture = container.captureRepository
            capture.store(parsed, settings.mediaCaptureEnabled)
            detectVanished(parsed)

            val hasMedia = parsed.messages.any { !it.isDeletionPlaceholder && it.category.mediaType != null }
            if (settings.mediaCaptureEnabled && hasMedia) WorkScheduler.scheduleScanSoon(this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to capture notification", e)
        }
    }

    private suspend fun detectVanished(parsed: ParsedNotification) {
        val capture = container.captureRepository
        val real = parsed.messages.filter { !it.isDeletionPlaceholder }
        val placeholders = parsed.messages.filter { it.isDeletionPlaceholder }
        val current = real.map {
            SnapshotEntry(capture.dedupeKey(parsed.packageName, it), it.senderName, it.timestamp)
        }
        val previous = snapshots[parsed.notificationKey]
        if (previous != null && real.isNotEmpty()) {
            val currentKeys = current.map { it.dedupeKey }.toHashSet()
            // WhatsApp trims the OLDEST lines when a notification gets long; that is not deletion.
            val oldestShown = real.minOf { it.timestamp }
            val vanished = previous.filter { it.dedupeKey !in currentKeys && it.timestamp >= oldestShown }
            for (v in vanished) {
                val confirmed = placeholders.any { it.senderName == v.sender }
                capture.markDeleted(
                    v.dedupeKey,
                    if (confirmed) RecoveryStatus.DELETED_CONFIRMED else RecoveryStatus.DELETED_SUSPECTED
                )
            }
        } else if (previous != null && real.isEmpty() && placeholders.isNotEmpty()) {
            // The only message(s) in the notification were replaced by deletion notices.
            for (v in previous) {
                if (placeholders.any { it.senderName == v.sender }) {
                    capture.markDeleted(v.dedupeKey, RecoveryStatus.DELETED_CONFIRMED)
                }
            }
        }
        snapshots[parsed.notificationKey] = current
    }

    companion object {
        private const val TAG = "VaultListener"
        const val PKG_WHATSAPP = "com.whatsapp"
        const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
        val WHATSAPP_PACKAGES = setOf(PKG_WHATSAPP, PKG_WHATSAPP_BUSINESS)

        private val _connected = MutableStateFlow(false)
        /** True while Android has this listener bound (in this process). */
        val connected: StateFlow<Boolean> = _connected

        fun requestRebindIfNeeded(context: Context) {
            if (_connected.value) return
            runCatching {
                NotificationListenerService.requestRebind(ComponentName(context, VaultNotificationListener::class.java))
            }
        }
    }
}
