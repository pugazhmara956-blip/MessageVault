package com.messagevault.app.data.repo

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.messagevault.app.capture.ParsedMessage
import com.messagevault.app.capture.ParsedNotification
import com.messagevault.app.data.db.ArchivedMessage
import com.messagevault.app.data.db.ContactInfo
import com.messagevault.app.data.db.VaultDatabase
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.RecoveryStatus
import com.messagevault.app.media.MediaImporter
import com.messagevault.app.security.FieldCipher
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

/** Writes captured notification content into the encrypted local archive. */
class CaptureRepository(
    private val context: Context,
    private val db: VaultDatabase,
    private val cipher: FieldCipher,
    private val importer: MediaImporter
) {

    data class StoreResult(val inserted: Int, val confirmedDeletions: Int)

    fun dedupeKey(packageName: String, m: ParsedMessage): String {
        // When the timestamp only comes from the notification, bucket it to the minute so
        // repeated updates of the same notification do not create duplicates.
        val ts = if (m.stableTimestamp) m.timestamp.toString() else (m.timestamp / 60_000L).toString()
        return sha256("$packageName|${m.conversationKey}|${m.senderName}|$ts|${m.text}")
    }

    suspend fun store(parsed: ParsedNotification, captureMedia: Boolean): StoreResult {
        var inserted = 0
        var confirmed = 0
        val now = System.currentTimeMillis()
        val mediaMessages = parsed.messages.count { !it.isDeletionPlaceholder && it.category.mediaType != null }

        for (m in parsed.messages) {
            if (m.isDeletionPlaceholder) {
                // WhatsApp replaced a message with "This message was deleted" at the same timestamp.
                val original = db.messageDao().findForPlaceholder(
                    parsed.packageName, m.conversationKey, m.senderName, m.timestamp
                )
                if (original != null) {
                    db.messageDao().updateStatus(original.id, RecoveryStatus.DELETED_CONFIRMED, now)
                    confirmed++
                }
                continue
            }

            val key = dedupeKey(parsed.packageName, m)
            if (db.messageDao().findByKey(key) != null) continue

            val contactId = upsertContact(parsed.packageName, m, now)
            val id = db.messageDao().insert(
                ArchivedMessage(
                    dedupeKey = key,
                    packageName = parsed.packageName,
                    conversationKey = m.conversationKey,
                    conversationTitle = m.conversationTitle,
                    isGroup = m.isGroup,
                    senderName = m.senderName,
                    senderPhone = m.senderPhone,
                    contactId = contactId,
                    encryptedText = cipher.encrypt(m.text),
                    category = m.category,
                    attachmentHint = m.attachmentHint,
                    originalTimestamp = m.timestamp,
                    capturedAt = now,
                    notificationKey = parsed.notificationKey,
                    channelId = parsed.channelId,
                    status = RecoveryStatus.CAPTURED,
                    statusChangedAt = null
                )
            )
            if (id <= 0L) continue
            inserted++

            if (captureMedia && m.category.mediaType != null) {
                saveNotificationPreview(id, m, if (mediaMessages == 1) parsed.picture else null)
            }
        }
        return StoreResult(inserted, confirmed)
    }

    /** Marks a message (by dedupe key) as deleted. Never downgrades a confirmed status. */
    suspend fun markDeleted(dedupeKey: String, status: RecoveryStatus): Boolean =
        db.messageDao().markDeletedByKey(dedupeKey, status, System.currentTimeMillis()) > 0

    private suspend fun upsertContact(pkg: String, m: ParsedMessage, now: Long): Long? {
        val identity = if (m.isGroup) "group:${m.conversationKey}" else (m.senderPhone ?: m.senderName)
        val key = "$pkg|$identity"
        val dao = db.contactDao()
        val existing = dao.findByKey(key)
        if (existing != null) {
            val name = if (m.isGroup) m.conversationTitle else m.senderName
            dao.touch(existing.id, name, if (m.isGroup) null else m.senderPhone, now)
            return existing.id
        }
        val id = dao.insert(
            ContactInfo(
                contactKey = key,
                displayName = if (m.isGroup) m.conversationTitle else m.senderName,
                phoneNumber = if (m.isGroup) null else m.senderPhone,
                isGroup = m.isGroup,
                packageName = pkg,
                firstSeenAt = now,
                lastSeenAt = now
            )
        )
        return if (id > 0) id else dao.findByKey(key)?.id
    }

    /**
     * Saves the image preview WhatsApp attached to the notification (if any). This is a reduced
     * preview, not the original file; the full file is linked later by the media scanner.
     */
    private suspend fun saveNotificationPreview(messageId: Long, m: ParsedMessage, picture: Bitmap?) {
        val type = m.category.mediaType ?: return
        try {
            val uri = m.dataUri
            if (uri != null && (m.dataMimeType?.startsWith("image/") == true)) {
                val ext = if (m.dataMimeType == "image/webp") "webp" else "jpg"
                val result = importer.import(
                    open = { context.contentResolver.openInputStream(uri) },
                    fileName = "notification_preview_${m.timestamp}.$ext",
                    mimeType = m.dataMimeType,
                    type = if (type == MediaType.STICKER) MediaType.STICKER else MediaType.IMAGE,
                    origin = MediaOrigin.NOTIFICATION_PREVIEW,
                    sourceUri = uri.toString(),
                    sourceLastModified = m.timestamp,
                    declaredSize = 0,
                    messageId = messageId
                )
                if (result is MediaImporter.Result.Imported || result is MediaImporter.Result.Duplicate) return
            }
            if (picture != null && (m.category == MessageCategory.IMAGE || m.category == MessageCategory.VIDEO)) {
                val bytes = ByteArrayOutputStream().use { out ->
                    picture.compress(Bitmap.CompressFormat.JPEG, 92, out)
                    out.toByteArray()
                }
                importer.import(
                    open = { ByteArrayInputStream(bytes) },
                    fileName = "notification_preview_${m.timestamp}.jpg",
                    mimeType = "image/jpeg",
                    type = MediaType.IMAGE,
                    origin = MediaOrigin.NOTIFICATION_PREVIEW,
                    sourceUri = null,
                    sourceLastModified = m.timestamp,
                    declaredSize = bytes.size.toLong(),
                    messageId = messageId
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Notification preview not saved: ${e.message}")
        }
    }

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private companion object {
        const val TAG = "CaptureRepository"
    }
}
