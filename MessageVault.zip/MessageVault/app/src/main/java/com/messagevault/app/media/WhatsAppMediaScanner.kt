package com.messagevault.app.media

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.ContextCompat
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType

/**
 * Finds WhatsApp media files the user has authorised access to and copies new ones into the vault.
 *
 * Sources (both official, both user-granted):
 *  1. Storage Access Framework tree the user picked (e.g. Android/media/com.whatsapp/WhatsApp/Media).
 *  2. Optional MediaStore query for WhatsApp folders indexed in the gallery.
 *
 * A file that WhatsApp never downloaded (auto-download off, or deleted before download) does not
 * exist on the phone, so it cannot be archived. This is reported, never faked.
 */
class WhatsAppMediaScanner(
    private val context: Context,
    private val importer: MediaImporter
) {
    data class Report(
        var examined: Int = 0,
        var imported: Int = 0,
        var duplicates: Int = 0,
        var skipped: Int = 0,
        var failed: Int = 0,
        val problems: MutableList<String> = mutableListOf()
    )

    private data class DocEntry(
        val documentId: String,
        val name: String,
        val mime: String,
        val size: Long,
        val lastModified: Long
    ) {
        val isDirectory get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
    }

    fun hasTreeAccess(treeUri: String?): Boolean {
        if (treeUri == null) return false
        return context.contentResolver.persistedUriPermissions.any {
            it.uri.toString() == treeUri && it.isReadPermission
        }
    }

    suspend fun scanTree(treeUriString: String, since: Long, report: Report) {
        val treeUri = Uri.parse(treeUriString)
        if (!hasTreeAccess(treeUriString)) {
            report.problems += "Access to the WhatsApp media folder was revoked. Choose the folder again in Storage."
            return
        }
        val rootId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (e: Exception) {
            report.problems += "The saved folder link is invalid. Choose the folder again."
            return
        }
        walk(treeUri, rootId, emptyList(), since, report, depth = 0)
    }

    private suspend fun walk(
        treeUri: Uri,
        documentId: String,
        path: List<String>,
        since: Long,
        report: Report,
        depth: Int
    ) {
        if (depth > 8) return
        val children = try {
            listChildren(treeUri, documentId)
        } catch (e: Exception) {
            report.problems += "Could not read folder ${path.joinToString("/")}: ${e.message}"
            return
        }
        for (child in children) {
            if (child.name.startsWith(".")) continue
            if (child.isDirectory) {
                if (SKIP_DIRS.any { child.name.equals(it, ignoreCase = true) }) continue
                walk(treeUri, child.documentId, path + child.name, since, report, depth + 1)
                continue
            }
            if (child.lastModified in 1 until since) continue
            if (child.size == 0L) continue
            val type = typeForPath(path, child.mime, child.name) ?: continue
            report.examined++
            val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, child.documentId)
            importOne(fileUri, child.name, child.mime, type, MediaOrigin.WHATSAPP_FOLDER, child.lastModified, child.size, report)
        }
    }

    private fun listChildren(treeUri: Uri, documentId: String): List<DocEntry> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        val out = mutableListOf<DocEntry>()
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                out += DocEntry(
                    documentId = c.getString(0) ?: continue,
                    name = c.getString(1) ?: "",
                    mime = c.getString(2) ?: "application/octet-stream",
                    size = if (c.isNull(3)) 0L else c.getLong(3),
                    lastModified = if (c.isNull(4)) 0L else c.getLong(4)
                )
            }
        }
        return out
    }

    /** Media type from the WhatsApp folder name, falling back to MIME type. Null = ignore. */
    private fun typeForPath(path: List<String>, mime: String, name: String): MediaType? {
        val joined = path.joinToString("/").lowercase()
        if (SKIP_PATH_PARTS.any { joined.contains(it) }) return null
        return when {
            joined.contains("voice notes") -> MediaType.VOICE_NOTE
            joined.contains("animated gifs") -> MediaType.GIF
            joined.contains("stickers") -> MediaType.STICKER
            joined.contains("images") -> MediaType.IMAGE
            joined.contains("video") -> MediaType.VIDEO
            joined.contains("audio") -> MediaType.AUDIO
            joined.contains("documents") -> MediaType.DOCUMENT
            else -> MediaImporter.typeFromMime(mime, name)
        }
    }

    fun hasMediaStorePermission(): Boolean {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return perms.any { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    }

    suspend fun scanMediaStore(since: Long, report: Report) {
        if (!hasMediaStorePermission()) {
            report.problems += "Gallery permission not granted; gallery index was skipped."
            return
        }
        val collections = listOf(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI to MediaType.IMAGE,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI to MediaType.VIDEO,
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to MediaType.AUDIO
        )
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.RELATIVE_PATH
        )
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? AND ${MediaStore.MediaColumns.DATE_MODIFIED} >= ?"
        val args = arrayOf("%WhatsApp%", (since / 1000L).toString())

        for ((collection, baseType) in collections) {
            try {
                context.contentResolver.query(collection, projection, selection, args, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2) ?: MediaImporter.guessMime(name)
                        val size = c.getLong(3)
                        val modified = c.getLong(4) * 1000L
                        val rel = (c.getString(5) ?: "").lowercase()
                        if (size == 0L || name.startsWith(".")) continue
                        if (SKIP_PATH_PARTS.any { rel.contains(it) }) continue
                        val type = when {
                            rel.contains("voice notes") -> MediaType.VOICE_NOTE
                            rel.contains("animated gifs") -> MediaType.GIF
                            rel.contains("stickers") -> MediaType.STICKER
                            else -> baseType
                        }
                        report.examined++
                        val uri = ContentUris.withAppendedId(collection, id)
                        importOne(uri, name, mime, type, MediaOrigin.MEDIA_STORE, modified, size, report)
                    }
                }
            } catch (e: Exception) {
                report.problems += "Gallery query failed: ${e.message}"
            }
        }
    }

    private suspend fun importOne(
        uri: Uri,
        name: String,
        mime: String,
        type: MediaType,
        origin: MediaOrigin,
        lastModified: Long,
        size: Long,
        report: Report
    ) {
        val uriString = uri.toString()
        if (importer.alreadyImported(uriString, lastModified, size)) {
            report.duplicates++
            return
        }
        when (val r = importer.import(
            open = { context.contentResolver.openInputStream(uri) },
            fileName = name,
            mimeType = mime,
            type = type,
            origin = origin,
            sourceUri = uriString,
            sourceLastModified = lastModified,
            declaredSize = size
        )) {
            is MediaImporter.Result.Imported -> report.imported++
            is MediaImporter.Result.Duplicate -> report.duplicates++
            is MediaImporter.Result.Skipped -> {
                report.skipped++
                if (report.problems.size < 20) report.problems += "$name: ${r.reason}"
            }
            is MediaImporter.Result.Failed -> {
                report.failed++
                Log.w(TAG, "Import failed for $name: ${r.error}")
                if (report.problems.size < 20) report.problems += "$name: ${r.error}"
            }
        }
    }

    companion object {
        private const val TAG = "MediaScanner"

        /** Folders that are not chat media (or are the user's own sent files / private data). */
        private val SKIP_DIRS = listOf(
            "Sent", "Private", "Databases", "Backups", "WhatsApp Profile Photos",
            "Profile Pictures", "WallPaper", "Wallpaper"
        )
        private val SKIP_PATH_PARTS = listOf(
            "/sent", ".statuses", "profile photos", "wallpaper", "databases", "backups", "/private"
        )

        /** Where WhatsApp keeps media: Android 11+ uses Android/media, Android 10 the old root folder. */
        fun suggestedInitialUri(): Uri = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                "primary:Android/media/com.whatsapp/WhatsApp/Media"
            } else {
                "primary:WhatsApp/Media"
            }
        )
    }
}
