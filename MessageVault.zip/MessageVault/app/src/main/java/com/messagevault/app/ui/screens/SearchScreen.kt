package com.messagevault.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.ui.components.EmptyState
import com.messagevault.app.ui.components.MessageRow
import com.messagevault.app.ui.components.VaultScaffold
import com.messagevault.app.ui.viewmodel.DateRange
import com.messagevault.app.ui.viewmodel.SearchViewModel

/** Screen 15: full-text search with contact, date and content-type filters. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(vm: SearchViewModel, onOpenMessage: (Long) -> Unit, onBack: () -> Unit) {
    val filters by vm.filters.collectAsState()
    val results by vm.results.collectAsState()
    val senders by vm.senders.collectAsState()
    val focus = remember { FocusRequester() }
    var contactMenu by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    VaultScaffold(title = "Search", onBack = onBack) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = filters.query,
                onValueChange = { q -> vm.update { it.copy(query = q) } },
                placeholder = { Text("Search text, contact, group or number") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (filters.query.isNotEmpty()) IconButton(onClick = { vm.update { it.copy(query = "") } }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear")
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).focusRequester(focus)
            )

            // Content type
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filters.deletedOnly,
                    onClick = { vm.update { it.copy(deletedOnly = !it.deletedOnly) } },
                    label = { Text("Deleted only") }
                )
                FilterChip(
                    selected = filters.category == null,
                    onClick = { vm.update { it.copy(category = null) } },
                    label = { Text("All types") }
                )
                MessageCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = filters.category == cat,
                        onClick = { vm.update { it.copy(category = if (it.category == cat) null else cat) } },
                        label = { Text(cat.label) }
                    )
                }
            }

            // Date + contact
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box {
                    FilterChip(
                        selected = filters.contact != null,
                        onClick = { contactMenu = true },
                        label = { Text(filters.contact ?: "Any contact") },
                        trailingIcon = { Icon(Icons.Rounded.ArrowDropDown, contentDescription = null) }
                    )
                    DropdownMenu(expanded = contactMenu, onDismissRequest = { contactMenu = false }, modifier = Modifier.heightIn(max = 360.dp)) {
                        DropdownMenuItem(text = { Text("Any contact") }, onClick = {
                            vm.update { it.copy(contact = null) }
                            contactMenu = false
                        })
                        senders.forEach { s ->
                            DropdownMenuItem(text = { Text(s) }, onClick = {
                                vm.update { it.copy(contact = s) }
                                contactMenu = false
                            })
                        }
                    }
                }
                DateRange.entries.forEach { r ->
                    FilterChip(
                        selected = filters.range == r,
                        onClick = { vm.update { it.copy(range = r) } },
                        label = { Text(r.label) }
                    )
                }
            }

            val list = results
            when {
                list == null -> {}
                list.isEmpty() -> EmptyState(Icons.Rounded.SearchOff, "No matches", "Try a different word or remove some filters.")
                else -> LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    item {
                        Text(
                            "${list.size} result${if (list.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    items(list, key = { it.id }) { m ->
                        MessageRow(m, onClick = { onOpenMessage(m.id) }, modifier = Modifier.padding(bottom = 8.dp))
                    }
                }
            }
        }
    }
}
