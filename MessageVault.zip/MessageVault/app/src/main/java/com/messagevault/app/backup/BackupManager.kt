package com.messagevault.app.backup

import android.content.Context
import android.net.Uri
import com.messagevault.app.data.db.ArchivedMessage
import com.messagevault.app.data.db.VaultDatabase
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.RecoveryStatus
import com.messagevault.app.media.MediaImporter
import com.messagevault.app.security.FieldCipher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Password-protected, portable backups (.mvault).
 *
 * Contents: a JSON manifest of all messages (decrypted, so the backup is independent of this
 * phone's Keystore) plus every archived media file, zipped, then encrypted with AES-256-GCM
 * using a key derived from the user's password (PBKDF2-HMAC-SHA256). The file is written to a
 * location the user chooses through the Storage Access Framework. Nothing is uploaded anywhere.
 *
 * File format: "MVBK" | version(1) | salt(16) | iterations(int) | chunks...
 * Each chunk: length(int) | iv(12) | ciphertext. AAD = chunk index + final flag, so chunks
 * cannot be reordered or truncated without detection.
 */
class BackupManager(
    private val context: Context,
    private val db: VaultDatabase,
    private val cipher: FieldCipher,
    private val importer: MediaImporter
) {
    data class RestoreSummary(val messagesAdded: Int, val mediaAdded: Int, val skippedDuplicates: Int)

    class BackupException(message: String) : Exception(message)

    suspend fun export(target: Uri, password: CharArray): Int = withContext(Dispatchers.IO) {
        val tmpZip = File(context.cacheDir, "mv_backup_${System.nanoTime()}.zip")
        try {
            val messages = db.messageDao().getAll()
            val allMedia = db.mediaDao().getAllOldestFirst()
            val manifest = JSONObject().apply {
                put("format", "message-vault-backup")
                put("version", 1)
                put("createdAt", System.currentTimeMillis())
                put("messages", JSONArray().apply { messages.forEach { put(messageJson(it)) } })
                put("media", JSONArray().apply {
                    allMedia.forEach { m ->
                        if (File(m.localPath).exists()) put(JSONObject().apply {
                            put("sha256", m.sha256)
                            put("messageId", m.messageId ?: JSONObject.NULL)
                            put("mediaType", m.mediaType.name)
                            put("fileName", m.fileName)
                            put("mimeType", m.mimeType)
                            put("origin", m.origin.name)
                            put("sourceLastModified", m.sourceLastModified)
                        })
                    }
                })
            }
            ZipOutputStream(tmpZip.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry(MANIFEST))
                zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                allMedia.forEach { m ->
                    val f = File(m.localPath)
                    if (f.exists()) {
                        zip.putNextEntry(ZipEntry("media/${m.sha256}"))
                        f.inputStream().buffered().use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
            val out = context.contentResolver.openOutputStream(target, "w")
                ?: throw BackupException("Could not open the chosen backup location")
            out.use { o -> tmpZip.inputStream().buffered().use { encrypt(it, o, password) } }
            messages.size
        } finally {
            tmpZip.delete()
        }
    }

    suspend fun restore(source: Uri, password: CharArray): RestoreSummary = withContext(Dispatchers.IO) {
        val tmpZip = File(context.cacheDir, "mv_restore_${System.nanoTime()}.zip")
        try {
            val input = context.contentResolver.openInputStream(source)
                ?: throw BackupException("Could not open the backup file")
            input.use { i -> tmpZip.outputStream().buffered().use { decrypt(i, it, password) } }

            var messagesAdded = 0
            var mediaAdded = 0
            var duplicates = 0
            ZipFile(tmpZip).use { zip ->
                val manifestEntry = zip.getEntry(MANIFEST) ?: throw BackupException("Backup manifest missing")
                val manifest = JSONObject(zip.getInputStream(manifestEntry).bufferedReader().readText())
                if (manifest.optString("format") != "message-vault-backup") throw BackupException("Not a Message Vault backup")

                val idMap = HashMap<Long, Long>()
                val msgs = manifest.getJSONArray("messages")
                for (i in 0 until msgs.length()) {
                    val o = msgs.getJSONObject(i)
                    val oldId = o.getLong("id")
                    val key = o.getString("dedupeKey")
                    val existing = db.messageDao().findByKey(key)
                    if (existing != null) {
                        idMap[oldId] = existing.id
                        duplicates++
                        continue
                    }
                    val newId = db.messageDao().insert(
                        ArchivedMessage(
                            dedupeKey = key,
                            packageName = o.getString("packageName"),
                            conversationKey = o.getString("conversationKey"),
                            conversationTitle = o.getString("conversationTitle"),
                            isGroup = o.getBoolean("isGroup"),
                            senderName = o.getString("senderName"),
                            senderPhone = o.optStringOrNull("senderPhone"),
                            contactId = null,
                            encryptedText = cipher.encrypt(o.getString("text")),
                            category = enumOr(o.getString("category"), MessageCategory.OTHER),
                            attachmentHint = o.optStringOrNull("attachmentHint"),
                            originalTimestamp = o.getLong("originalTimestamp"),
                            capturedAt = o.getLong("capturedAt"),
                            notificationKey = o.optStringOrNull("notificationKey"),
                            channelId = o.optStringOrNull("channelId"),
                            status = enumOr(o.getString("status"), RecoveryStatus.CAPTURED),
                            statusChangedAt = if (o.isNull("statusChangedAt")) null else o.getLong("statusChangedAt")
                        )
                    )
                    if (newId > 0) {
                        idMap[oldId] = newId
                        messagesAdded++
                    }
                }

                val media = manifest.getJSONArray("media")
                val hexOnly = Regex("^[0-9a-f]{64}$")
                for (i in 0 until media.length()) {
                    val o = media.getJSONObject(i)
                    val hash = o.getString("sha256")
                    if (!hexOnly.matches(hash)) continue
                    if (db.mediaDao().findByHash(hash) != null) {
                        duplicates++
                        continue
                    }
                    val entry = zip.getEntry("media/$hash") ?: continue
                    val oldMsg = if (o.isNull("messageId")) null else o.getLong("messageId")
                    val result = importer.import(
                        open = { zip.getInputStream(entry) },
                        fileName = o.getString("fileName"),
                        mimeType = o.getString("mimeType"),
                        type = enumOr(o.getString("mediaType"), MediaType.DOCUMENT),
                        origin = if (o.getString("origin") == MediaOrigin.NOTIFICATION_PREVIEW.name)
                            MediaOrigin.NOTIFICATION_PREVIEW else MediaOrigin.BACKUP_RESTORE,
                        sourceUri = null,
                        sourceLastModified = o.optLong("sourceLastModified"),
                        declaredSize = 0,
                        messageId = oldMsg?.let { idMap[it] }
                    )
                    if (result is MediaImporter.Result.Imported) mediaAdded++
                }
            }
            RestoreSummary(messagesAdded, mediaAdded, duplicates)
        } catch (e: AEADBadTagException) {
            throw BackupException("Wrong password, or the backup file is damaged")
        } finally {
            tmpZip.delete()
        }
    }

    private fun messageJson(m: ArchivedMessage) = JSONObject().apply {
        put("id", m.id)
        put("dedupeKey", m.dedupeKey)
        put("packageName", m.packageName)
        put("conversationKey", m.conversationKey)
        put("conversationTitle", m.conversationTitle)
        put("isGroup", m.isGroup)
        put("senderName", m.senderName)
        put("senderPhone", m.senderPhone ?: JSONObject.NULL)
        put("text", cipher.decrypt(m.encryptedText))
        put("category", m.category.name)
        put("attachmentHint", m.attachmentHint ?: JSONObject.NULL)
        put("originalTimestamp", m.originalTimestamp)
        put("capturedAt", m.capturedAt)
        put("notificationKey", m.notificationKey ?: JSONObject.NULL)
        put("channelId", m.channelId ?: JSONObject.NULL)
        put("status", m.status.name)
        put("statusChangedAt", m.statusChangedAt ?: JSONObject.NULL)
    }

    // ---- Chunked AES-GCM ---------------------------------------------------------------------

    private fun deriveKey(password: CharArray, salt: ByteArray, iterations: Int): SecretKey {
        val spec = PBEKeySpec(password, salt, iterations, 256)
        return try {
            SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    private fun aad(index: Long, final: Boolean): ByteArray =
        ByteBuffer.allocate(9).putLong(index).put((if (final) 1 else 0).toByte()).array()

    private fun encrypt(input: InputStream, output: OutputStream, password: CharArray) {
        val random = SecureRandom()
        val salt = ByteArray(16).also { random.nextBytes(it) }
        val key = deriveKey(password, salt, ITERATIONS)
        val out = DataOutputStream(output.buffered())
        out.write(MAGIC)
        out.writeByte(VERSION)
        out.write(salt)
        out.writeInt(ITERATIONS)

        val buffer = ByteArray(CHUNK)
        var index = 0L
        fun writeChunk(data: ByteArray, len: Int, final: Boolean) {
            val iv = ByteArray(12).also { random.nextBytes(it) }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
            c.updateAAD(aad(index++, final))
            val ct = c.doFinal(data, 0, len)
            out.writeInt(ct.size)
            out.write(iv)
            out.write(ct)
        }
        while (true) {
            var filled = 0
            while (filled < CHUNK) {
                val r = input.read(buffer, filled, CHUNK - filled)
                if (r < 0) break
                filled += r
            }
            if (filled > 0) writeChunk(buffer, filled, final = false)
            if (filled < CHUNK) break
        }
        writeChunk(ByteArray(0), 0, final = true)
        out.flush()
    }

    private fun decrypt(input: InputStream, output: OutputStream, password: CharArray) {
        val inp = DataInputStream(input.buffered())
        val magic = ByteArray(4)
        try {
            inp.readFully(magic)
        } catch (e: EOFException) {
            throw BackupException("The file is empty or not a Message Vault backup")
        }
        if (!magic.contentEquals(MAGIC)) throw BackupException("Not a Message Vault backup (.mvault) file")
        val version = inp.readUnsignedByte()
        if (version != VERSION) throw BackupException("Unsupported backup version $version")
        val salt = ByteArray(16).also { inp.readFully(it) }
        val iterations = inp.readInt()
        if (iterations !in 10_000..5_000_000) throw BackupException("Backup header is damaged")
        val key = deriveKey(password, salt, iterations)

        var index = 0L
        while (true) {
            val len = try {
                inp.readInt()
            } catch (e: EOFException) {
                throw BackupException("Backup file is incomplete (truncated)")
            }
            if (len < 16 || len > CHUNK + 16) throw BackupException("Backup file is damaged")
            val iv = ByteArray(12).also { inp.readFully(it) }
            val ct = ByteArray(len).also { inp.readFully(it) }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            // Try as a normal chunk first, then as the final marker.
            val plain = try {
                c.updateAAD(aad(index, false))
                c.doFinal(ct)
            } catch (e: AEADBadTagException) {
                val f = Cipher.getInstance("AES/GCM/NoPadding")
                f.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                f.updateAAD(aad(index, true))
                f.doFinal(ct) // throws AEADBadTagException on wrong password
                return
            }
            output.write(plain)
            index++
        }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String, default: T): T =
        runCatching { enumValueOf<T>(name) }.getOrDefault(default)

    private fun JSONObject.optStringOrNull(key: String): String? =
        if (isNull(key)) null else optString(key).takeIf { it.isNotEmpty() }

    companion object {
        const val FILE_EXTENSION = "mvault"
        const val MIME = "application/octet-stream"
        private const val MANIFEST = "manifest.json"
        private val MAGIC = byteArrayOf('M'.code.toByte(), 'V'.code.toByte(), 'B'.code.toByte(), 'K'.code.toByte())
        private const val VERSION = 1
        private const val ITERATIONS = 210_000
        private const val CHUNK = 1024 * 1024
    }
}
