package com.messagevault.app.data.db

import androidx.room.TypeConverter
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.RecoveryStatus

/** Enums are stored by name so the database stays readable and stable. */
class Converters {
    @TypeConverter fun categoryToString(v: MessageCategory): String = v.name
    @TypeConverter fun stringToCategory(v: String): MessageCategory =
        runCatching { MessageCategory.valueOf(v) }.getOrDefault(MessageCategory.OTHER)

    @TypeConverter fun mediaTypeToString(v: MediaType): String = v.name
    @TypeConverter fun stringToMediaType(v: String): MediaType =
        runCatching { MediaType.valueOf(v) }.getOrDefault(MediaType.DOCUMENT)

    @TypeConverter fun statusToString(v: RecoveryStatus): String = v.name
    @TypeConverter fun stringToStatus(v: String): RecoveryStatus =
        runCatching { RecoveryStatus.valueOf(v) }.getOrDefault(RecoveryStatus.CAPTURED)

    @TypeConverter fun originToString(v: MediaOrigin): String = v.name
    @TypeConverter fun stringToOrigin(v: String): MediaOrigin =
        runCatching { MediaOrigin.valueOf(v) }.getOrDefault(MediaOrigin.WHATSAPP_FOLDER)
}
