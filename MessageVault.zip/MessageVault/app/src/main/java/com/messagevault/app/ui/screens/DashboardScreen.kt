package com.messagevault.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.messagevault.app.capture.VaultNotificationListener
import com.messagevault.app.data.model.MediaArchiveKind
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.MessageFilter
import com.messagevault.app.ui.components.CategoryTile
import com.messagevault.app.ui.components.EmptyState
import com.messagevault.app.ui.components.MessageRow
import com.messagevault.app.ui.components.SectionHeader
import com.messagevault.app.ui.components.StatCard
import com.messagevault.app.ui.components.VaultCard
import com.messagevault.app.ui.components.VaultLogo
import com.messagevault.app.ui.components.WarningCard
import com.messagevault.app.ui.theme.VaultColors
import com.messagevault.app.ui.viewmodel.DashboardState
import com.messagevault.app.ui.viewmodel.DashboardViewModel
import com.messagevault.app.util.Format
import com.messagevault.app.util.SystemStatus

private data class Category(val label: String, val icon: ImageVector, val tint: Color, val count: Int, val onClick: () -> Unit)

@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    onOpenMessages: (MessageFilter) -> Unit,
    onOpenMedia: (MediaArchiveKind) -> Unit,
    onOpenMessage: (Long) -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onNotificationGuide: () -> Unit,
    onPermissionSetup: () -> Unit
) {
    val state by vm.state.collectAsState()
    val sys = rememberSystemState()
    val c = state.counts

    val categories = listOf(
        Category("All messages", Icons.Rounded.Forum, VaultColors.Indigo, c.totalMessages) { onOpenMessages(MessageFilter.ALL) },
        Category("Deleted", Icons.Rounded.DeleteSweep, VaultColors.Rose, c.deletedMessages) { onOpenMessages(MessageFilter.DELETED) },
        Category("Text", Icons.AutoMirrored.Rounded.Chat, VaultColors.Sky, c.byCategory[MessageCategory.TEXT] ?: 0) { onOpenMessages(MessageFilter.TEXT) },
        Category("Images", Icons.Rounded.Image, VaultColors.Teal, c.mediaCount(MediaArchiveKind.IMAGES)) { onOpenMedia(MediaArchiveKind.IMAGES) },
        Category("Videos", Icons.Rounded.Videocam, VaultColors.Violet, c.mediaCount(MediaArchiveKind.VIDEOS)) { onOpenMedia(MediaArchiveKind.VIDEOS) },
        Category("Voice notes", Icons.Rounded.Mic, VaultColors.Amber, c.mediaCount(MediaArchiveKind.VOICE)) { onOpenMedia(MediaArchiveKind.VOICE) },
        Category("Audio", Icons.Rounded.AudioFile, VaultColors.Sky, c.mediaCount(MediaArchiveKind.AUDIO)) { onOpenMedia(MediaArchiveKind.AUDIO) },
        Category("Documents", Icons.Rounded.Description, VaultColors.Coral, c.mediaCount(MediaArchiveKind.DOCUMENTS)) { onOpenMedia(MediaArchiveKind.DOCUMENTS) },
        Category("Stickers", Icons.Rounded.EmojiEmotions, VaultColors.Lime, c.mediaCount(MediaArchiveKind.STICKERS)) { onOpenMedia(MediaArchiveKind.STICKERS) }
    )

    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 32.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                VaultLogo(42.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Message Vault", style = MaterialTheme.typography.titleLarge)
                    Text("Private recovery archive", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalIconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, contentDescription = "Search") }
                Spacer(Modifier.width(6.dp))
                FilledTonalIconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, contentDescription = "Settings") }
            }
        }
        item {
            AnimatedVisibility(appeared, enter = fadeIn() + slideInVertically { it / 6 }) {
                Column {
                    Spacer(Modifier.height(8.dp))
                    RecoveryStatusCard(state, sys.listenerEnabled, onNotificationGuide)
                    StatusWarnings(state, sys, onNotificationGuide, onPermissionSetup)
                }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Saved messages", "${c.totalMessages}", Icons.Rounded.Forum, VaultColors.Indigo, Modifier.weight(1f)) { onOpenMessages(MessageFilter.ALL) }
                StatCard("Saved media", "${c.totalMedia}", Icons.Rounded.PermMedia, VaultColors.Teal, Modifier.weight(1f)) { onOpenMedia(MediaArchiveKind.IMAGES) }
            }
            Spacer(Modifier.height(12.dp))
            StatCard(
                "Deleted-message archive · ${Format.bytes(c.mediaBytes)} media stored",
                "${c.deletedMessages}",
                Icons.Rounded.DeleteSweep,
                VaultColors.Rose,
                Modifier.fillMaxWidth()
            ) { onOpenMessages(MessageFilter.DELETED) }
        }
        item { SectionHeader("Categories") }
        items(categories.chunked(3)) { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { cat ->
                    CategoryTile(cat.label, cat.count, cat.icon, cat.tint, Modifier.weight(1f), cat.onClick)
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        item {
            SectionHeader("Recently captured") {
                if (state.recent.isNotEmpty()) TextButton(onClick = { onOpenMessages(MessageFilter.ALL) }) { Text("See all") }
            }
        }
        if (state.loaded && state.recent.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.Inbox,
                    "Nothing captured yet",
                    if (sys.listenerEnabled) "New WhatsApp messages will appear here as soon as their notification arrives."
                    else "Grant notification access to start capturing WhatsApp messages."
                )
            }
        }
        items(state.recent, key = { it.id }) { m ->
            MessageRow(m, onClick = { onOpenMessage(m.id) }, modifier = Modifier.padding(bottom = 8.dp))
        }
        item { Spacer(Modifier.navigationBarsPadding()) }
    }
}

@Composable
private fun RecoveryStatusCard(state: DashboardState, listenerEnabled: Boolean, onFix: () -> Unit) {
    val context = LocalContext.current
    val s = state.settings
    val (title, body, color) = when {
        !listenerEnabled -> Triple("Capture is off", "Notification access is not granted, so no messages can be captured.", MaterialTheme.colorScheme.error)
        !s.backgroundCaptureEnabled -> Triple("Capture paused", "Background capture is turned off in Settings.", VaultColors.Amber)
        !s.whatsappCaptureEnabled && !s.whatsappBusinessCaptureEnabled -> Triple("Capture paused", "WhatsApp capture is turned off in Settings.", VaultColors.Amber)
        !state.listenerConnected -> Triple("Starting listener…", "Access is granted. Android has not started the listener yet. If this persists, tap Fix.", VaultColors.Amber)
        else -> Triple("Recovery active", "Listening for WhatsApp notifications. Last activity: ${Format.relative(s.lastWhatsAppNotificationAt)}.", VaultColors.Teal)
    }
    VaultCard(container = color.copy(alpha = 0.10f), onClick = if (color == VaultColors.Teal) null else ({
        if (listenerEnabled) VaultNotificationListener.requestRebindIfNeeded(context)
        onFix()
    })) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(10.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, color = color, modifier = Modifier.weight(1f))
            if (color != VaultColors.Teal) Text("Fix", style = MaterialTheme.typography.labelLarge, color = color)
        }
        Spacer(Modifier.height(6.dp))
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun StatusWarnings(state: DashboardState, sys: SystemState, onGuide: () -> Unit, onSetup: () -> Unit) {
    val context = LocalContext.current
    val s = state.settings
    val now = System.currentTimeMillis()
    val day = 24L * 60 * 60 * 1000

    if (!sys.whatsappInstalled) {
        Spacer(Modifier.height(10.dp))
        WarningCard("WhatsApp is not installed", "Install WhatsApp or WhatsApp Business to capture messages.")
    }
    if (s.previewHiddenDetectedAt > now - 7 * day) {
        Spacer(Modifier.height(10.dp))
        WarningCard(
            "WhatsApp is hiding message previews",
            "Recent WhatsApp notifications only said \"new message\" without the text. Turn message previews back on in WhatsApp, otherwise message text cannot be captured.",
            "WhatsApp notification settings",
            { SystemStatus.openWhatsAppNotificationSettings(context) }
        )
    }
    if (sys.listenerEnabled && state.listenerConnected && s.lastListenerConnectedAt in 1 until now - 2 * day &&
        (s.lastWhatsAppNotificationAt == 0L || s.lastWhatsAppNotificationAt < now - 3 * day)
    ) {
        Spacer(Modifier.height(10.dp))
        WarningCard(
            "No WhatsApp notifications seen recently",
            "WhatsApp notifications may be turned off or blocked. Android does not let other apps check WhatsApp's notification settings directly, so please verify them.",
            "Check WhatsApp notifications",
            { SystemStatus.openWhatsAppNotificationSettings(context) }
        )
    }
    if (s.mediaCaptureEnabled && s.mediaTreeUri == null && !s.mediaStoreScanEnabled) {
        Spacer(Modifier.height(10.dp))
        WarningCard(
            "Media folder not connected",
            "Text is being captured, but photos, videos, voice notes and documents need access to the WhatsApp media folder.",
            "Connect folder",
            onSetup
        )
    }
    if (sys.isXiaomi && !sys.batteryUnrestricted && sys.listenerEnabled) {
        Spacer(Modifier.height(10.dp))
        WarningCard(
            "Redmi battery saver may stop capture",
            "Set Battery saver to \"No restrictions\" and enable Autostart for reliable capture after restarts.",
            "Open guide",
            onGuide
        )
    }
}
