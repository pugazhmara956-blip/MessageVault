package com.messagevault.app.ui.screens

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.messagevault.app.MessageVaultApp
import com.messagevault.app.util.SystemStatus

/** System facts that can change while the app is in the background; refreshed on every resume. */
data class SystemState(
    val listenerEnabled: Boolean,
    val whatsappInstalled: Boolean,
    val batteryUnrestricted: Boolean,
    val mediaPermission: Boolean,
    val biometricAvailable: Boolean,
    val isXiaomi: Boolean
)

@Composable
fun rememberSystemState(): SystemState {
    val context = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    return remember(tick) {
        val app = context.applicationContext as MessageVaultApp
        SystemState(
            listenerEnabled = SystemStatus.isListenerEnabled(context),
            whatsappInstalled = SystemStatus.isWhatsAppInstalled(context),
            batteryUnrestricted = SystemStatus.isIgnoringBatteryOptimizations(context),
            mediaPermission = app.container.mediaScanner.hasMediaStorePermission(),
            biometricAvailable = SystemStatus.canUseBiometrics(context),
            isXiaomi = SystemStatus.isXiaomiFamily()
        )
    }
}

fun Context.findFragmentActivity(): FragmentActivity? {
    var c: Context? = this
    while (c is android.content.ContextWrapper) {
        if (c is FragmentActivity) return c
        c = c.baseContext
    }
    return null
}
