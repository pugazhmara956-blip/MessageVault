package com.messagevault.app

import android.app.Application
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.decode.VideoFrameDecoder
import com.messagevault.app.work.WorkScheduler
import kotlinx.coroutines.launch

class MessageVaultApp : Application(), ImageLoaderFactory {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.appScope.launch { container.settingsRepository.ensureDefaults() }
        WorkScheduler.schedulePeriodic(this)
    }

    /** Local-only image loading: photos, animated GIF/WebP stickers and video frames. */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components {
            add(VideoFrameDecoder.Factory())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) add(ImageDecoderDecoder.Factory())
            else add(GifDecoder.Factory())
        }
        .crossfade(true)
        .build()
}
