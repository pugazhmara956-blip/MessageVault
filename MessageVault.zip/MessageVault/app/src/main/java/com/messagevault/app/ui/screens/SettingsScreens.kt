package com.messagevault.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Business
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Password
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Screenshot
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.messagevault.app.BuildConfig
import com.messagevault.app.backup.BackupManager
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.media.WhatsAppMediaScanner
import com.messagevault.app.ui.components.InfoRow
import com.messagevault.app.ui.components.SectionHeader
import com.messagevault.app.ui.components.SettingNavRow
import com.messagevault.app.ui.components.SettingSwitchRow
import com.messagevault.app.ui.components.VaultCard
import com.messagevault.app.ui.components.VaultLogo
import com.messagevault.app.ui.components.VaultScaffold
import com.messagevault.app.ui.components.WarningCard
import com.messagevault.app.ui.components.categoryTint
import com.messagevault.app.ui.theme.VaultColors
import com.messagevault.app.ui.viewmodel.SettingsViewModel
import com.messagevault.app.util.Format
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Shows the view model's one-shot messages as snackbars. */
@Composable
private fun MessageSnackbar(vm: SettingsViewModel, host: SnackbarHostState) {
    val msg by vm.message.collectAsState()
    LaunchedEffect(msg) {
        msg?.let {
            host.showSnackbar(it)
            vm.consumeMessage()
        }
    }
}

// ---- 18. Settings -----------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    vm: SettingsViewModel,
    onBack: () -> Unit,
    onPermissionSetup: () -> Unit,
    onNotificationGuide: () -> Unit,
    onStorage: () -> Unit,
    onPrivacy: () -> Unit,
    onAbout: () -> Unit
) {
    val s by vm.settings.collectAsState()
    val sys = rememberSystemState()

    VaultScaffold(title = "Settings", onBack = onBack) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            VaultCard(container = MaterialTheme.colorScheme.surfaceContainerLow) {
                Text("How capture works", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Message text is captured only through Android Notification Access. If WhatsApp notifications are off, a chat is muted, or previews are hidden, nothing can be captured. Message Vault itself never posts notifications.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!sys.listenerEnabled) {
                Spacer(Modifier.height(10.dp))
                WarningCard("Notification access is off", "Capture cannot work until access is granted.", "Grant access", onNotificationGuide, critical = true)
            }

            SectionHeader("Capture")
            SettingSwitchRow(Icons.Rounded.PlayCircle, "Background capture", "Master switch for all capture", s.backgroundCaptureEnabled) { v ->
                vm.update { it.copy(backgroundCaptureEnabled = v) }
            }
            SettingSwitchRow(Icons.Rounded.Notifications, "WhatsApp capture", "com.whatsapp", s.whatsappCaptureEnabled, enabled = s.backgroundCaptureEnabled) { v ->
                vm.update { it.copy(whatsappCaptureEnabled = v) }
            }
            SettingSwitchRow(Icons.Rounded.Business, "WhatsApp Business capture", "com.whatsapp.w4b", s.whatsappBusinessCaptureEnabled, enabled = s.backgroundCaptureEnabled) { v ->
                vm.update { it.copy(whatsappBusinessCaptureEnabled = v) }
            }
            SettingSwitchRow(Icons.Rounded.PermMedia, "Media capture", "Copy downloaded WhatsApp media into the vault", s.mediaCaptureEnabled, enabled = s.backgroundCaptureEnabled) { v ->
                vm.update { it.copy(mediaCaptureEnabled = v) }
            }
            SettingSwitchRow(
                Icons.Rounded.PhotoLibrary,
                "Use gallery index too",
                if (sys.mediaPermission) "Extra media source via MediaStore" else "Needs gallery permission (Permission setup)",
                s.mediaStoreScanEnabled && sys.mediaPermission,
                enabled = s.mediaCaptureEnabled && sys.mediaPermission
            ) { v -> vm.update { it.copy(mediaStoreScanEnabled = v) } }

            SectionHeader("Appearance")
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                com.messagevault.app.ui.components.TintedIcon(Icons.Rounded.DarkMode, MaterialTheme.colorScheme.primary, 38.dp)
                Spacer(Modifier.width(14.dp))
                val options = listOf("System", "Dark", "Light")
                SingleChoiceSegmentedButtonRow(Modifier.weight(1f)) {
                    options.forEachIndexed { index, label ->
                        SegmentedButton(
                            selected = s.themeMode == index,
                            onClick = { vm.update { it.copy(themeMode = index) } },
                            shape = SegmentedButtonDefaults.itemShape(index, options.size)
                        ) { Text(label) }
                    }
                }
            }

            SectionHeader("More")
            SettingNavRow(Icons.Rounded.Tune, "Permission setup", "Notification access, media folder, battery") { onPermissionSetup() }
            SettingNavRow(Icons.Rounded.Notifications, "Notification access help", "Restricted settings, Xiaomi tips") { onNotificationGuide() }
            SettingNavRow(Icons.Rounded.Storage, "Storage management", "Usage, cleanup, backup & restore", VaultColors.Teal) { onStorage() }
            SettingNavRow(Icons.Rounded.Security, "Privacy & security", "App lock, PIN, fingerprint", VaultColors.Violet) { onPrivacy() }
            SettingNavRow(Icons.Rounded.Info, "About Message Vault", "Version, how it works, limitations", VaultColors.Sky) { onAbout() }
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ---- 16. Storage management -------------------------------------------------------------------

@Composable
fun StorageScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val s by vm.settings.collectAsState()
    val counts by vm.counts.collectAsState()
    val storage by vm.storage.collectAsState()
    val busy by vm.busy.collectAsState()
    val host = remember { SnackbarHostState() }
    MessageSnackbar(vm, host)
    LaunchedEffect(counts.totalMedia, counts.totalMessages) { vm.refreshStorage() }

    var passwordFor by remember { mutableStateOf<PasswordPurpose?>(null) }
    var pendingUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.setMediaFolder(context, uri)
    }
    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(BackupManager.MIME)) { uri ->
        if (uri != null) { pendingUri = uri; passwordFor = PasswordPurpose.EXPORT }
    }
    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { pendingUri = uri; passwordFor = PasswordPurpose.RESTORE }
    }

            VaultScaffold(title = "Storage management", onBack = onBack, snackbarHost = { SnackbarHost(host) }) { padding ->
                Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(bottom = 8.dp))

                    VaultCard {
                        Text("Storage used", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val total = (storage?.mediaBytes ?: 0L) + (storage?.databaseBytes ?: 0L)
                        Text(Format.bytes(total), style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        InfoRow("Messages", "${counts.totalMessages}")
                        InfoRow("Media files", "${counts.totalMedia} · ${Format.bytes(storage?.mediaBytes ?: 0)}")
                        InfoRow("Database", Format.bytes(storage?.databaseBytes ?: 0))
                        if (s.storageLimitMb > 0) InfoRow("Limit", "${s.storageLimitMb} MB")
                        Spacer(Modifier.height(10.dp))
                        MediaType.entries.forEach { t ->
                            val n = counts.mediaByType[t] ?: 0
                            if (n > 0) {
                                Text("${t.label}: $n", style = MaterialTheme.typography.bodySmall)
                                LinearProgressIndicator(
                                    progress = { n.toFloat() / counts.totalMedia.coerceAtLeast(1) },
                                    color = categoryTint(t.category),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                )
                            }
                        }
                        if (counts.totalMedia == 0) {
                            Text("No media archived yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    SectionHeader("WhatsApp media folder")
                    VaultCard {
                        val ok = s.mediaTreeUri != null && vm.hasTreeAccess()
                        Text(
                            when {
                                ok -> "Connected"
                                s.mediaTreeUri != null -> "Access lost — choose the folder again"
                                else -> "Not connected"
                            },
                            style = MaterialTheme.typography.titleSmall,
                            color = if (ok) VaultColors.Teal else VaultColors.Amber
                        )
                        Text(
                            "Last scan: ${Format.relative(s.lastMediaScanAt)}. New media is scanned every ~15 minutes and shortly after each WhatsApp media message.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            androidx.compose.material3.FilledTonalButton(onClick = { treeLauncher.launch(WhatsAppMediaScanner.suggestedInitialUri()) }) {
                                Text(if (s.mediaTreeUri == null) "Choose folder" else "Change")
                            }
                            androidx.compose.material3.OutlinedButton(onClick = { vm.scanNow(context, full = false) }) { Text("Scan now") }
                        }
                        TextButton(onClick = { vm.scanNow(context, full = true) }) { Text("Import all existing WhatsApp media") }
                        Text(
                            "The first scan only imports media from the last 7 days. \"Import all\" copies every existing file and can use a lot of storage.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    SectionHeader("Automatic cleanup")
                    ChoiceChips(
                        options = listOf(0 to "Never", 30 to "30 days", 90 to "90 days", 180 to "180 days", 365 to "1 year"),
                        selected = s.autoCleanupDays
                    ) { v -> vm.update { it.copy(autoCleanupDays = v) } }
                    Text("Deletes archived records older than the chosen age. Runs daily.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    SectionHeader("Media storage limit")
                    ChoiceChips(
                        options = listOf(0 to "No limit", 1024 to "1 GB", 2048 to "2 GB", 5120 to "5 GB", 10240 to "10 GB"),
                        selected = s.storageLimitMb
                    ) { v -> vm.update { it.copy(storageLimitMb = v) } }
                    Text("When the limit is exceeded, the oldest media copies are removed first. Message text is kept.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { vm.runCleanup(context) }) { Text("Run cleanup now") }

                    SectionHeader("Backup & restore")
                    SettingNavRow(Icons.Rounded.Backup, "Create encrypted backup", "Password-protected .mvault file saved where you choose") {
                        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                        createBackup.launch("MessageVault_$stamp.${BackupManager.FILE_EXTENSION}")
                    }
                    SettingNavRow(Icons.Rounded.Restore, "Restore from backup", "Merges into the current archive, skipping duplicates") {
                        openBackup.launch(arrayOf("*/*"))
                    }

                    SectionHeader("Danger zone")
                    SettingNavRow(Icons.Rounded.DeleteForever, "Clear entire archive", "Permanently deletes all messages and media copies", MaterialTheme.colorScheme.error) {
                        confirmClear = true
                    }
                    SettingNavRow(Icons.Rounded.CleaningServices, "Refresh usage", null) { vm.refreshStorage() }
                    Spacer(Modifier.height(40.dp))
                }
            }

    passwordFor?.let { purpose ->
        PasswordDialog(
            purpose = purpose,
            onDismiss = { passwordFor = null; pendingUri = null },
            onConfirm = { pw ->
                val uri = pendingUri
                passwordFor = null
                pendingUri = null
                if (uri != null) {
                    if (purpose == PasswordPurpose.EXPORT) vm.exportBackup(uri, pw) else vm.restoreBackup(uri, pw)
                }
            }
        )
    }
    if (confirmClear) {
        var typed by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear the entire archive?") },
            text = {
                Column {
                    Text("All ${counts.totalMessages} messages and ${counts.totalMedia} media copies will be deleted permanently. Type DELETE to confirm.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(typed, { typed = it }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(enabled = typed.trim() == "DELETE", onClick = {
                    confirmClear = false
                    vm.clearArchive()
                }) { Text("Delete everything", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ChoiceChips(options: List<Pair<Int, String>>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (value, label) ->
            FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

enum class PasswordPurpose { EXPORT, RESTORE }

@Composable
private fun PasswordDialog(purpose: PasswordPurpose, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    val export = purpose == PasswordPurpose.EXPORT
    val valid = if (export) pw.length >= 6 && pw == pw2 else pw.isNotEmpty()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (export) "Protect backup with a password" else "Enter backup password") },
        text = {
            Column {
                if (export) {
                    Text(
                        "The backup contains your messages in readable form once decrypted. Choose a strong password (min. 6 characters). It cannot be recovered if forgotten.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = pw,
                    onValueChange = { pw = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                if (export) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pw2,
                        onValueChange = { pw2 = it },
                        label = { Text("Repeat password") },
                        singleLine = true,
                        isError = pw2.isNotEmpty() && pw2 != pw,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                }
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onConfirm(pw) }) { Text(if (export) "Create backup" else "Restore") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---- 17. Privacy & security -------------------------------------------------------------------

@Composable
fun PrivacySecurityScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()
    val sys = rememberSystemState()
    val host = remember { SnackbarHostState() }
    MessageSnackbar(vm, host)
    var pinDialog by remember { mutableStateOf<PinDialogMode?>(null) }

            VaultScaffold(title = "Privacy & security", onBack = onBack, snackbarHost = { SnackbarHost(host) }) { padding ->
                Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                    SectionHeader("App lock")
                    SettingSwitchRow(
                        Icons.Rounded.Lock,
                        "App lock",
                        if (s.appLockEnabled) "PIN required to open Message Vault" else "Off",
                        s.appLockEnabled
                    ) { on ->
                        pinDialog = if (on) PinDialogMode.CREATE else PinDialogMode.DISABLE
                    }
                    SettingSwitchRow(
                        Icons.Rounded.Fingerprint,
                        "Unlock with fingerprint / face",
                        if (sys.biometricAvailable) "Uses Android biometric authentication" else "No enrolled biometrics on this phone",
                        s.biometricEnabled && sys.biometricAvailable,
                        enabled = s.appLockEnabled && sys.biometricAvailable
                    ) { on -> vm.update { it.copy(biometricEnabled = on) } }
                    if (s.appLockEnabled) {
                        SettingNavRow(Icons.Rounded.Password, "Change PIN") { pinDialog = PinDialogMode.CHANGE }
                    }

                    SectionHeader("Screen")
                    SettingSwitchRow(
                        Icons.Rounded.Screenshot,
                        "Block screenshots & recents preview",
                        "Hides archive content from screenshots, screen recording and the recent-apps view",
                        s.secureScreen
                    ) { on -> vm.update { it.copy(secureScreen = on) } }

                    SectionHeader("How your data is protected")
                    VaultCard {
                        PrivacyFact("No internet permission", "The app cannot connect to the internet at all. Nothing is uploaded or shared.")
                        PrivacyFact("Encrypted text", "Message text is encrypted with AES-256-GCM. The key is wrapped by a non-exportable key in the Android Keystore.")
                        PrivacyFact("Private storage", "Media copies live in app-private storage that other apps cannot read.")
                        PrivacyFact("Excluded from cloud backup", "Android's automatic cloud backup and device transfer are disabled for this app.")
                        PrivacyFact("No Accessibility, no root", "Only Notification Access and the folder you choose are used. WhatsApp is never modified.")
                        PrivacyFact("Your responsibility", "Archived messages were sent to you by other people. Respect their privacy and local laws when viewing or sharing them.")
                    }
                    Spacer(Modifier.height(40.dp))
                }
            }

    pinDialog?.let { mode ->
        PinDialog(
            mode = mode,
            verify = { vm.verifyPin(it) },
            onDismiss = { pinDialog = null },
            onSetPin = { pin -> vm.setPin(pin).also { if (it) pinDialog = null } },
            onDisable = { vm.disableLock(); pinDialog = null }
        )
    }
}

@Composable
private fun PrivacyFact(title: String, body: String) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

enum class PinDialogMode { CREATE, CHANGE, DISABLE }

@Composable
private fun PinDialog(
    mode: PinDialogMode,
    verify: (String) -> Boolean,
    onDismiss: () -> Unit,
    onSetPin: (String) -> Boolean,
    onDisable: () -> Unit
) {
    var current by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val needsCurrent = mode != PinDialogMode.CREATE
    val needsNew = mode != PinDialogMode.DISABLE
    val digits: (String) -> String = { it.filter(Char::isDigit).take(8) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when (mode) {
                    PinDialogMode.CREATE -> "Create a PIN"
                    PinDialogMode.CHANGE -> "Change PIN"
                    PinDialogMode.DISABLE -> "Turn off app lock"
                }
            )
        },
        text = {
            Column {
                if (needsCurrent) {
                    OutlinedTextField(
                        current, { current = digits(it) }, label = { Text("Current PIN") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    Spacer(Modifier.height(8.dp))
                }
                if (needsNew) {
                    OutlinedTextField(
                        pin, { pin = digits(it) }, label = { Text("New PIN (4–8 digits)") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        pin2, { pin2 = digits(it) }, label = { Text("Repeat new PIN") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                }
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (needsCurrent && !verify(current)) { error = "Current PIN is wrong"; return@TextButton }
                if (!needsNew) { onDisable(); return@TextButton }
                if (pin.length < 4) { error = "PIN must have 4–8 digits"; return@TextButton }
                if (pin != pin2) { error = "PINs do not match"; return@TextButton }
                if (!onSetPin(pin)) error = "Could not save PIN"
            }) { Text(if (mode == PinDialogMode.DISABLE) "Turn off" else "Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---- 19. About --------------------------------------------------------------------------------

@Composable
fun AboutScreen(onBack: () -> Unit) {
    VaultScaffold(title = "About", onBack = onBack) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 12.dp)) {
                VaultLogo(64.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Message Vault", style = MaterialTheme.typography.titleLarge)
                    Text("Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            SectionHeader("How it works")
            Text(
                "1. When WhatsApp posts a notification, Android delivers a copy to Message Vault through the official NotificationListenerService.\n" +
                    "2. The visible text, sender, group and time are saved immediately in an encrypted local database — before anything can be deleted.\n" +
                    "3. If WhatsApp later replaces the message with \"This message was deleted\", or it vanishes from the live notification, the saved copy is flagged in the Deleted archive.\n" +
                    "4. Media that WhatsApp downloads into its media folder is copied into private storage and linked to the closest matching message.",
                style = MaterialTheme.typography.bodyMedium
            )

            SectionHeader("Technical limitations")
            VaultCard(container = MaterialTheme.colorScheme.surfaceContainerLow) {
                Text(
                    "• Only notification content can be captured. WhatsApp's own database is end-to-end encrypted and private; reading it is neither possible nor attempted.\n" +
                        "• No notification = no capture: open chats, muted chats, disabled notifications and hidden previews produce nothing to save.\n" +
                        "• Long messages may be shortened by WhatsApp in the notification; only that version can be saved.\n" +
                        "• Deletion is not always signalled. WhatsApp may simply remove the notification (the same thing happens when you read a message elsewhere), so the copy stays in \"All messages\" without a deleted flag.\n" +
                        "• Media is only available if WhatsApp downloaded the file (auto-download) before it was deleted. View-once media is never saved to storage and cannot be archived.\n" +
                        "• Media-to-message links are matched by time and type and may occasionally be wrong in busy chats.\n" +
                        "• Phone numbers are shown only when WhatsApp includes them (e.g. unsaved contacts).\n" +
                        "• Some phone makers (including Xiaomi/HyperOS) may stop background apps; follow the battery tips in Permission setup.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            SectionHeader("Privacy")
            Text(
                "Message Vault has no internet permission, no analytics and no ads. All data stays on this phone until you delete it or export an encrypted backup yourself.",
                style = MaterialTheme.typography.bodyMedium
            )
            SectionHeader("Not affiliated")
            Text(
                "Message Vault is an independent tool and is not affiliated with, endorsed by, or connected to WhatsApp or Meta. \"WhatsApp\" is used only to describe compatibility.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(40.dp))
        }
    }
}
