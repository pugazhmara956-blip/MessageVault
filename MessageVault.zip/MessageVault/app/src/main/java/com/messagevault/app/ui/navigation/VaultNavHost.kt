package com.messagevault.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.messagevault.app.data.db.CaptureSettings
import com.messagevault.app.data.model.MediaArchiveKind
import com.messagevault.app.data.model.MessageFilter
import com.messagevault.app.ui.screens.AboutScreen
import com.messagevault.app.ui.screens.DashboardScreen
import com.messagevault.app.ui.screens.MediaArchiveScreen
import com.messagevault.app.ui.screens.MediaViewerScreen
import com.messagevault.app.ui.screens.MessageDetailScreen
import com.messagevault.app.ui.screens.MessageListScreen
import com.messagevault.app.ui.screens.NotificationAccessScreen
import com.messagevault.app.ui.screens.PermissionSetupScreen
import com.messagevault.app.ui.screens.PrivacySecurityScreen
import com.messagevault.app.ui.screens.SearchScreen
import com.messagevault.app.ui.screens.SettingsScreen
import com.messagevault.app.ui.screens.SplashScreen
import com.messagevault.app.ui.screens.StorageScreen
import com.messagevault.app.ui.screens.WelcomeScreen
import com.messagevault.app.ui.viewmodel.VaultViewModels

object Routes {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val ONBOARDING_PERMISSIONS = "onboarding_permissions"
    const val PERMISSIONS = "permissions"
    const val NOTIFICATION_ACCESS = "notification_access"
    const val DASHBOARD = "dashboard"
    const val MESSAGES = "messages/{filter}"
    const val MEDIA = "media/{kind}"
    const val MESSAGE = "message/{id}"
    const val MEDIA_VIEW = "media_view/{id}"
    const val SEARCH = "search"
    const val STORAGE = "storage"
    const val PRIVACY = "privacy"
    const val SETTINGS = "settings"
    const val ABOUT = "about"

    fun messages(filter: MessageFilter) = "messages/${filter.name}"
    fun media(kind: MediaArchiveKind) = "media/${kind.name}"
    fun message(id: Long) = "message/$id"
    fun mediaView(id: Long) = "media_view/$id"
}

@Composable
fun VaultNavHost(nav: NavHostController, settings: CaptureSettings?) {
    val back: () -> Unit = { nav.popBackStack() }
    val vmFactory = VaultViewModels.Factory

    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        enterTransition = { fadeIn(tween(220)) + slideInHorizontally(tween(260)) { it / 10 } },
        exitTransition = { fadeOut(tween(160)) },
        popEnterTransition = { fadeIn(tween(220)) },
        popExitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(220)) { it / 10 } }
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(settings) { done ->
                nav.navigate(if (done) Routes.DASHBOARD else Routes.WELCOME) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            }
        }
        composable(Routes.WELCOME) {
            WelcomeScreen(onContinue = { nav.navigate(Routes.ONBOARDING_PERMISSIONS) })
        }
        composable(Routes.ONBOARDING_PERMISSIONS) {
            PermissionSetupScreen(
                vm = viewModel(factory = vmFactory),
                onOpenNotificationGuide = { nav.navigate(Routes.NOTIFICATION_ACCESS) },
                onOpenPrivacy = { nav.navigate(Routes.PRIVACY) },
                onFinish = {
                    nav.navigate(Routes.DASHBOARD) { popUpTo(0) { inclusive = true } }
                },
                onBack = null
            )
        }
        composable(Routes.PERMISSIONS) {
            PermissionSetupScreen(
                vm = viewModel(factory = vmFactory),
                onOpenNotificationGuide = { nav.navigate(Routes.NOTIFICATION_ACCESS) },
                onOpenPrivacy = { nav.navigate(Routes.PRIVACY) },
                onFinish = back,
                onBack = back
            )
        }
        composable(Routes.NOTIFICATION_ACCESS) { NotificationAccessScreen(onBack = back) }
        composable(Routes.DASHBOARD) {
            DashboardScreen(
                vm = viewModel(factory = vmFactory),
                onOpenMessages = { nav.navigate(Routes.messages(it)) },
                onOpenMedia = { nav.navigate(Routes.media(it)) },
                onOpenMessage = { nav.navigate(Routes.message(it)) },
                onSearch = { nav.navigate(Routes.SEARCH) },
                onSettings = { nav.navigate(Routes.SETTINGS) },
                onNotificationGuide = { nav.navigate(Routes.NOTIFICATION_ACCESS) },
                onPermissionSetup = { nav.navigate(Routes.PERMISSIONS) }
            )
        }
        composable(Routes.MESSAGES, arguments = listOf(navArgument("filter") { type = NavType.StringType })) {
            MessageListScreen(
                vm = viewModel(factory = vmFactory),
                onOpenMessage = { nav.navigate(Routes.message(it)) },
                onSearch = { nav.navigate(Routes.SEARCH) },
                onBack = back
            )
        }
        composable(Routes.MEDIA, arguments = listOf(navArgument("kind") { type = NavType.StringType })) {
            MediaArchiveScreen(
                vm = viewModel(factory = vmFactory),
                onOpenMedia = { nav.navigate(Routes.mediaView(it)) },
                onBack = back
            )
        }
        composable(Routes.MESSAGE, arguments = listOf(navArgument("id") { type = NavType.LongType })) {
            MessageDetailScreen(
                vm = viewModel(factory = vmFactory),
                onOpenMedia = { nav.navigate(Routes.mediaView(it)) },
                onBack = back
            )
        }
        composable(Routes.MEDIA_VIEW, arguments = listOf(navArgument("id") { type = NavType.LongType })) {
            MediaViewerScreen(
                vm = viewModel(factory = vmFactory),
                onOpenMessage = { nav.navigate(Routes.message(it)) },
                onBack = back
            )
        }
        composable(Routes.SEARCH) {
            SearchScreen(vm = viewModel(factory = vmFactory), onOpenMessage = { nav.navigate(Routes.message(it)) }, onBack = back)
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                vm = viewModel(factory = vmFactory),
                onBack = back,
                onPermissionSetup = { nav.navigate(Routes.PERMISSIONS) },
                onNotificationGuide = { nav.navigate(Routes.NOTIFICATION_ACCESS) },
                onStorage = { nav.navigate(Routes.STORAGE) },
                onPrivacy = { nav.navigate(Routes.PRIVACY) },
                onAbout = { nav.navigate(Routes.ABOUT) }
            )
        }
        composable(Routes.STORAGE) { StorageScreen(vm = viewModel(factory = vmFactory), onBack = back) }
        composable(Routes.PRIVACY) { PrivacySecurityScreen(vm = viewModel(factory = vmFactory), onBack = back) }
        composable(Routes.ABOUT) { AboutScreen(onBack = back) }
    }
}
