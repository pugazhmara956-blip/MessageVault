package com.messagevault.app.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.messagevault.app.AppContainer
import com.messagevault.app.MessageVaultApp
import com.messagevault.app.backup.BackupManager
import com.messagevault.app.capture.VaultNotificationListener
import com.messagevault.app.data.db.CaptureSettings
import com.messagevault.app.data.model.MediaArchiveKind
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.MessageFilter
import com.messagevault.app.data.repo.ArchiveCounts
import com.messagevault.app.data.repo.ArchiveRepository
import com.messagevault.app.data.repo.MediaItem
import com.messagevault.app.data.repo.MessageItem
import com.messagevault.app.util.Format
import com.messagevault.app.work.WorkScheduler
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private fun CreationExtras.container(): AppContainer =
    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as MessageVaultApp).container

object VaultViewModels {
    val Factory: ViewModelProvider.Factory = viewModelFactory {
        initializer { AppViewModel(container()) }
        initializer { DashboardViewModel(container()) }
        initializer { MessageListViewModel(container().archiveRepository, createSavedStateHandle()) }
        initializer { MediaArchiveViewModel(container().archiveRepository, createSavedStateHandle()) }
        initializer { MessageDetailViewModel(container().archiveRepository, createSavedStateHandle()) }
        initializer { MediaViewerViewModel(container().archiveRepository, createSavedStateHandle()) }
        initializer { SearchViewModel(container().archiveRepository) }
        initializer { SettingsViewModel(container()) }
    }
}

private val started = SharingStarted.WhileSubscribed(5_000)

/** Activity-level state: settings (theme, lock, onboarding) and PIN verification. */
class AppViewModel(private val c: AppContainer) : ViewModel() {
    /** Null until the settings row has been read once. */
    val settings: StateFlow<CaptureSettings?> = c.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun verifyPin(pin: String): Boolean {
        val s = settings.value ?: return false
        return c.pinManager.verify(pin, s.pinHash, s.pinSalt)
    }
}

data class DashboardState(
    val counts: ArchiveCounts = ArchiveCounts(),
    val recent: List<MessageItem> = emptyList(),
    val settings: CaptureSettings = CaptureSettings(),
    val listenerConnected: Boolean = false,
    val loaded: Boolean = false
)

class DashboardViewModel(c: AppContainer) : ViewModel() {
    val state: StateFlow<DashboardState> = combine(
        c.archiveRepository.observeCounts(),
        c.archiveRepository.observeRecent(6),
        c.settingsRepository.settings,
        VaultNotificationListener.connected
    ) { counts, recent, settings, connected ->
        DashboardState(counts, recent, settings, connected, loaded = true)
    }.stateIn(viewModelScope, started, DashboardState())
}

/** A list item: either a day header or a message. */
sealed interface ListEntry {
    data class Header(val label: String, val key: String) : ListEntry
    data class Message(val item: MessageItem) : ListEntry
}

fun List<MessageItem>.withDayHeaders(): List<ListEntry> {
    val out = ArrayList<ListEntry>(size + 8)
    var lastDay = Long.MIN_VALUE
    for (m in this) {
        val day = Format.startOfDay(m.originalTimestamp)
        if (day != lastDay) {
            out += ListEntry.Header(Format.dayHeader(m.originalTimestamp), "h$day")
            lastDay = day
        }
        out += ListEntry.Message(m)
    }
    return out
}

class MessageListViewModel(repo: ArchiveRepository, handle: SavedStateHandle) : ViewModel() {
    val filter: MessageFilter = runCatching { MessageFilter.valueOf(handle.get<String>("filter") ?: "ALL") }
        .getOrDefault(MessageFilter.ALL)

    val entries: StateFlow<List<ListEntry>?> = repo.observeMessages(filter)
        .map { it.withDayHeaders() }
        .stateIn(viewModelScope, started, null)
}

class MediaArchiveViewModel(repo: ArchiveRepository, handle: SavedStateHandle) : ViewModel() {
    val kind: MediaArchiveKind = runCatching { MediaArchiveKind.valueOf(handle.get<String>("kind") ?: "IMAGES") }
        .getOrDefault(MediaArchiveKind.IMAGES)

    val items: StateFlow<List<MediaItem>?> = repo.observeMedia(kind).stateIn(viewModelScope, started, null)
}

class MessageDetailViewModel(private val repo: ArchiveRepository, handle: SavedStateHandle) : ViewModel() {
    private val id: Long = handle.get<Long>("id") ?: -1L

    /** Outer null = loading; inner null = record no longer exists. */
    val message: StateFlow<Result<MessageItem?>?> = repo.observeMessage(id)
        .map { Result.success(it) }
        .stateIn(viewModelScope, started, null)

    fun setMarkedDeleted(marked: Boolean) = viewModelScope.launch { repo.setMarkedDeleted(id, marked) }
    fun delete(onDone: () -> Unit) = viewModelScope.launch {
        repo.deleteMessage(id)
        onDone()
    }
}

class MediaViewerViewModel(private val repo: ArchiveRepository, handle: SavedStateHandle) : ViewModel() {
    private val id: Long = handle.get<Long>("id") ?: -1L

    val media: StateFlow<Result<MediaItem?>?> = repo.observeMediaItem(id)
        .map { Result.success(it) }
        .stateIn(viewModelScope, started, null)

    fun delete(onDone: () -> Unit) = viewModelScope.launch {
        repo.deleteMedia(id)
        onDone()
    }
}

enum class DateRange(val label: String, val days: Int?) {
    ANY("Any time", null), TODAY("Today", 0), WEEK("7 days", 7), MONTH("30 days", 30), YEAR("1 year", 365)
}

data class SearchFilters(
    val query: String = "",
    val category: MessageCategory? = null,
    val contact: String? = null,
    val range: DateRange = DateRange.ANY,
    val deletedOnly: Boolean = false
)

@OptIn(FlowPreview::class)
class SearchViewModel(repo: ArchiveRepository) : ViewModel() {
    private val _filters = MutableStateFlow(SearchFilters())
    val filters: StateFlow<SearchFilters> = _filters.asStateFlow()

    val senders: StateFlow<List<String>> = repo.observeSenders().stateIn(viewModelScope, started, emptyList())

    val results: StateFlow<List<MessageItem>?> = combine(
        repo.observeAllMessages(),
        _filters.debounce(200)
    ) { all, f ->
        val q = f.query.trim()
        val from = when (val d = f.range.days) {
            null -> Long.MIN_VALUE
            0 -> Format.startOfDay(System.currentTimeMillis())
            else -> System.currentTimeMillis() - d * 24L * 60 * 60 * 1000
        }
        all.filter { m ->
            (f.category == null || m.category == f.category) &&
                (f.contact == null || m.senderName == f.contact) &&
                m.originalTimestamp >= from &&
                (!f.deletedOnly || m.status.isDeleted) &&
                (q.isEmpty() ||
                    m.text.contains(q, ignoreCase = true) ||
                    m.senderName.contains(q, ignoreCase = true) ||
                    m.conversationTitle.contains(q, ignoreCase = true) ||
                    (m.senderPhone?.contains(q) == true) ||
                    (m.attachmentHint?.contains(q, ignoreCase = true) == true))
        }
    }.stateIn(viewModelScope, started, null)

    fun update(transform: (SearchFilters) -> SearchFilters) {
        _filters.value = transform(_filters.value)
    }
}

/** Settings, storage, privacy & onboarding actions. */
class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<CaptureSettings> = c.settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, CaptureSettings())
    val counts: StateFlow<ArchiveCounts> = c.archiveRepository.observeCounts()
        .stateIn(viewModelScope, started, ArchiveCounts())

    private val _storage = MutableStateFlow<ArchiveRepository.StorageInfo?>(null)
    val storage: StateFlow<ArchiveRepository.StorageInfo?> = _storage.asStateFlow()

    /** One-shot user-facing message (snackbar). */
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun consumeMessage() { _message.value = null }

    fun update(transform: (CaptureSettings) -> CaptureSettings) = viewModelScope.launch {
        c.settingsRepository.update(transform)
    }

    fun completeOnboarding() = update { it.copy(onboardingCompleted = true) }

    fun refreshStorage() = viewModelScope.launch { _storage.value = c.archiveRepository.storageInfo() }

    fun setMediaFolder(context: Context, uri: Uri) = viewModelScope.launch {
        try {
            val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
            // Release any older folder grant.
            val old = settings.value.mediaTreeUri
            if (old != null && old != uri.toString()) {
                runCatching { context.contentResolver.releasePersistableUriPermission(Uri.parse(old), flags) }
            }
            c.settingsRepository.update { it.copy(mediaTreeUri = uri.toString(), lastMediaScanAt = 0) }
            WorkScheduler.scanNow(context, full = false)
            _message.value = "Media folder saved. Scanning for recent media…"
        } catch (e: SecurityException) {
            _message.value = "Android did not allow persistent access to that folder."
        }
    }

    fun scanNow(context: Context, full: Boolean) {
        if (settings.value.mediaTreeUri == null && !settings.value.mediaStoreScanEnabled) {
            _message.value = "Choose the WhatsApp media folder first."
            return
        }
        WorkScheduler.scanNow(context, full)
        _message.value = if (full) "Importing all existing WhatsApp media in the background…" else "Scanning for new media…"
    }

    fun runCleanup(context: Context) {
        WorkScheduler.cleanupNow(context)
        _message.value = "Cleanup started"
    }

    fun setPin(pin: String): Boolean {
        if (!c.pinManager.isValidPin(pin)) return false
        val record = c.pinManager.create(pin)
        update { it.copy(pinHash = record.hash, pinSalt = record.salt, appLockEnabled = true) }
        _message.value = "PIN saved. App lock is on."
        return true
    }

    fun verifyPin(pin: String): Boolean = c.pinManager.verify(pin, settings.value.pinHash, settings.value.pinSalt)

    fun disableLock() = update { it.copy(appLockEnabled = false, biometricEnabled = false, pinHash = null, pinSalt = null) }

    fun exportBackup(uri: Uri, password: String) = viewModelScope.launch {
        _busy.value = true
        try {
            val n = c.backupManager.export(uri, password.toCharArray())
            _message.value = "Backup saved ($n messages)."
        } catch (e: Exception) {
            _message.value = "Backup failed: ${e.message}"
        } finally {
            _busy.value = false
        }
    }

    fun restoreBackup(uri: Uri, password: String) = viewModelScope.launch {
        _busy.value = true
        try {
            val r = c.backupManager.restore(uri, password.toCharArray())
            _message.value = "Restored ${r.messagesAdded} messages and ${r.mediaAdded} media files (${r.skippedDuplicates} duplicates skipped)."
            _storage.value = c.archiveRepository.storageInfo()
        } catch (e: BackupManager.BackupException) {
            _message.value = e.message
        } catch (e: Exception) {
            _message.value = "Restore failed: ${e.message}"
        } finally {
            _busy.value = false
        }
    }

    fun clearArchive() = viewModelScope.launch {
        _busy.value = true
        c.archiveRepository.clearArchive()
        _storage.value = c.archiveRepository.storageInfo()
        _busy.value = false
        _message.value = "Archive cleared."
    }

    fun hasTreeAccess(): Boolean = c.mediaScanner.hasTreeAccess(settings.value.mediaTreeUri)
}
