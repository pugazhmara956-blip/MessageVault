package com.messagevault.app

import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.rememberNavController
import com.messagevault.app.capture.VaultNotificationListener
import com.messagevault.app.ui.navigation.VaultNavHost
import com.messagevault.app.ui.screens.LockScreen
import com.messagevault.app.ui.theme.MessageVaultTheme
import com.messagevault.app.ui.viewmodel.AppViewModel
import com.messagevault.app.ui.viewmodel.VaultViewModels
import com.messagevault.app.util.SystemStatus

/**
 * Single activity. FragmentActivity (a ComponentActivity) is used because BiometricPrompt needs it.
 */
class MainActivity : FragmentActivity() {

    private val appVm: AppViewModel by viewModels { VaultViewModels.Factory }

    /** Unlocked state survives rotation but not process death (re-lock after restart). */
    private var unlocked by mutableStateOf(false)
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        unlocked = savedInstanceState?.getBoolean(KEY_UNLOCKED) ?: false
        splash.setKeepOnScreenCondition { appVm.settings.value == null }

        setContent {
            val settings by appVm.settings.collectAsState()
            val s = settings

            LaunchedEffect(s?.secureScreen) {
                if (s?.secureScreen != false) {
                    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            MessageVaultTheme(themeMode = s?.themeMode ?: 1) {
                val nav = rememberNavController()
                Box(Modifier.fillMaxSize()) {
                    VaultNavHost(nav, s)
                    val lockActive = s != null && s.onboardingCompleted && s.appLockEnabled && s.pinHash != null
                    if (lockActive && !unlocked) {
                        LockScreen(
                            biometricEnabled = s?.biometricEnabled == true && SystemStatus.canUseBiometrics(this@MainActivity),
                            verifyPin = { appVm.verifyPin(it) },
                            onUnlocked = { unlocked = true }
                        )
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (stoppedAt > 0 && SystemClock.elapsedRealtime() - stoppedAt > RELOCK_AFTER_MS) unlocked = false
        if (SystemStatus.isListenerEnabled(this)) VaultNotificationListener.requestRebindIfNeeded(this)
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_UNLOCKED, unlocked)
    }

    private companion object {
        const val KEY_UNLOCKED = "unlocked"
        const val RELOCK_AFTER_MS = 30_000L
    }
}
