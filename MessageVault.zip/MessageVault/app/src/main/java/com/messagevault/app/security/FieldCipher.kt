package com.messagevault.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Encrypts message text at rest with envelope encryption:
 *
 *  - A non-exportable AES-256 key lives in the Android Keystore (hardware-backed where available).
 *  - That Keystore key wraps a random 256-bit data key, stored wrapped in private SharedPreferences.
 *  - Message text is encrypted with the data key using AES-256-GCM (fast, in-process).
 *
 * Uninstalling the app destroys the Keystore key, so the database cannot be read elsewhere.
 * Portable backups are created separately with a user password (see BackupManager).
 */
class FieldCipher(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("vault_keys", Context.MODE_PRIVATE)
    private val random = SecureRandom()

    @Volatile
    private var cachedDataKey: SecretKey? = null

    fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        val iv = ByteArray(IV_BYTES).also { random.nextBytes(it) }
        cipher.init(Cipher.ENCRYPT_MODE, dataKey(), GCMParameterSpec(TAG_BITS, iv))
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv + ct, Base64.NO_WRAP)
    }

    fun decrypt(encoded: String): String = try {
        val all = Base64.decode(encoded, Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, dataKey(), GCMParameterSpec(TAG_BITS, all, 0, IV_BYTES))
        String(cipher.doFinal(all, IV_BYTES, all.size - IV_BYTES), Charsets.UTF_8)
    } catch (e: Exception) {
        UNREADABLE
    }

    @Synchronized
    private fun dataKey(): SecretKey {
        cachedDataKey?.let { return it }
        val wrapped = prefs.getString(PREF_WRAPPED_KEY, null)
        val raw: ByteArray = if (wrapped != null) {
            unwrap(Base64.decode(wrapped, Base64.NO_WRAP))
        } else {
            val fresh = ByteArray(32).also { random.nextBytes(it) }
            prefs.edit().putString(PREF_WRAPPED_KEY, Base64.encodeToString(wrap(fresh), Base64.NO_WRAP)).apply()
            fresh
        }
        return SecretKeySpec(raw, "AES").also { cachedDataKey = it }
    }

    private fun keystoreKey(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (ks.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun wrap(raw: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, keystoreKey()) // Keystore generates the IV
        return cipher.iv + cipher.doFinal(raw)
    }

    private fun unwrap(blob: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, keystoreKey(), GCMParameterSpec(TAG_BITS, blob, 0, IV_BYTES))
        return cipher.doFinal(blob, IV_BYTES, blob.size - IV_BYTES)
    }

    companion object {
        const val UNREADABLE = "[Unreadable – encryption key unavailable]"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "message_vault_kek_v1"
        private const val PREF_WRAPPED_KEY = "wrapped_data_key_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
        private const val TAG_BITS = 128
    }
}
