package com.messagevault.app.data.model

/** What kind of content a captured WhatsApp message represents (derived from notification text). */
enum class MessageCategory(val label: String) {
    TEXT("Text"),
    IMAGE("Image"),
    VIDEO("Video"),
    VOICE_NOTE("Voice note"),
    AUDIO("Audio"),
    DOCUMENT("Document"),
    GIF("GIF"),
    STICKER("Sticker"),
    CONTACT("Contact card"),
    LOCATION("Location"),
    POLL("Poll"),
    OTHER("Other");

    /** The media file type this message would carry, or null for non-media messages. */
    val mediaType: MediaType?
        get() = when (this) {
            IMAGE -> MediaType.IMAGE
            VIDEO -> MediaType.VIDEO
            VOICE_NOTE -> MediaType.VOICE_NOTE
            AUDIO -> MediaType.AUDIO
            DOCUMENT -> MediaType.DOCUMENT
            GIF -> MediaType.GIF
            STICKER -> MediaType.STICKER
            else -> null
        }
}

/** Type of an archived media file. */
enum class MediaType(val label: String) {
    IMAGE("Image"),
    VIDEO("Video"),
    VOICE_NOTE("Voice note"),
    AUDIO("Audio"),
    DOCUMENT("Document"),
    GIF("GIF"),
    STICKER("Sticker");

    val category: MessageCategory
        get() = when (this) {
            IMAGE -> MessageCategory.IMAGE
            VIDEO -> MessageCategory.VIDEO
            VOICE_NOTE -> MessageCategory.VOICE_NOTE
            AUDIO -> MessageCategory.AUDIO
            DOCUMENT -> MessageCategory.DOCUMENT
            GIF -> MessageCategory.GIF
            STICKER -> MessageCategory.STICKER
        }

    val isVisual: Boolean get() = this == IMAGE || this == VIDEO || this == GIF || this == STICKER
}

/**
 * Recovery status of a captured message.
 *
 * The app NEVER claims every deletion is detected. Deletion is only flagged when WhatsApp itself
 * exposes an indicator through its notification, or when the user marks a message manually.
 */
enum class RecoveryStatus(val label: String, val description: String) {
    CAPTURED(
        "Captured",
        "Saved from the notification. No deletion indicator has been seen for this message."
    ),
    DELETED_CONFIRMED(
        "Deleted by sender",
        "WhatsApp replaced this message in its notification with a \"This message was deleted\" notice. The text below is the copy saved before that happened."
    ),
    DELETED_SUSPECTED(
        "Possibly deleted",
        "This message disappeared from WhatsApp's live notification while newer messages stayed. That usually means it was deleted for everyone, but it cannot be confirmed."
    ),
    MARKED_DELETED(
        "Marked deleted",
        "You marked this message as deleted yourself."
    );

    val isDeleted: Boolean get() = this != CAPTURED
}

/** Where an archived media file came from. */
enum class MediaOrigin(val label: String) {
    WHATSAPP_FOLDER("WhatsApp media folder (user-authorised)"),
    MEDIA_STORE("Gallery index (MediaStore)"),
    NOTIFICATION_PREVIEW("Notification preview image"),
    BACKUP_RESTORE("Restored from backup")
}

/** Filters for the message list screens. */
enum class MessageFilter(val title: String) {
    ALL("All messages"),
    DELETED("Deleted archive"),
    TEXT("Text messages")
}

/** Media archive screens. Each one covers one or more media types. */
enum class MediaArchiveKind(val title: String, val types: List<MediaType>) {
    IMAGES("Images & GIFs", listOf(MediaType.IMAGE, MediaType.GIF)),
    VIDEOS("Videos", listOf(MediaType.VIDEO)),
    VOICE("Voice notes", listOf(MediaType.VOICE_NOTE)),
    AUDIO("Audio", listOf(MediaType.AUDIO)),
    STICKERS("Stickers", listOf(MediaType.STICKER)),
    DOCUMENTS("Documents", listOf(MediaType.DOCUMENT));

    val isGrid: Boolean get() = this == IMAGES || this == VIDEOS || this == STICKERS
}
