package com.messagevault.app.media

import android.content.Context
import android.webkit.MimeTypeMap
import com.messagevault.app.data.db.ArchivedMedia
import com.messagevault.app.data.db.VaultDatabase
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.repo.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.security.DigestInputStream
import java.security.MessageDigest
import java.util.UUID

/**
 * Copies media into app-private storage (filesDir/vault_media), de-duplicates by SHA-256 and links
 * each file to the most likely captured message.
 */
class MediaImporter(
    context: Context,
    private val db: VaultDatabase,
    private val settings: SettingsRepository
) {
    sealed interface Result {
        data class Imported(val mediaId: Long) : Result
        data class Duplicate(val mediaId: Long) : Result
        data class Skipped(val reason: String) : Result
        data class Failed(val error: String) : Result
    }

    val mediaRoot: File = File(context.filesDir, "vault_media").apply { mkdirs() }
    private val tmpDir: File = File(mediaRoot, ".tmp").apply { mkdirs() }
    private val importLock = Mutex()

    /** True when this exact source file (same uri, size, modified time) was already imported. */
    suspend fun alreadyImported(sourceUri: String, lastModified: Long, size: Long): Boolean =
        db.mediaDao().findBySource(sourceUri, lastModified, size) != null

    suspend fun import(
        open: () -> InputStream?,
        fileName: String,
        mimeType: String?,
        type: MediaType,
        origin: MediaOrigin,
        sourceUri: String?,
        sourceLastModified: Long,
        declaredSize: Long,
        messageId: Long? = null
    ): Result = withContext(Dispatchers.IO) {
        importLock.withLock {
            val limitMb = settings.current().storageLimitMb
            if (limitMb > 0 && declaredSize > 0) {
                val used = db.mediaDao().totalBytes()
                if (used + declaredSize > limitMb * 1024L * 1024L) {
                    return@withContext Result.Skipped("Storage limit of $limitMb MB reached")
                }
            }

            val tmp = File(tmpDir, UUID.randomUUID().toString())
            val digest = MessageDigest.getInstance("SHA-256")
            val copied: Long = try {
                val input = open() ?: return@withContext Result.Failed("Source could not be opened")
                DigestInputStream(input.buffered(), digest).use { din ->
                    tmp.outputStream().buffered().use { out -> din.copyTo(out) }
                }
            } catch (e: SecurityException) {
                tmp.delete()
                return@withContext Result.Failed("Access denied by Android: ${e.message}")
            } catch (e: Exception) {
                tmp.delete()
                return@withContext Result.Failed(e.message ?: e.javaClass.simpleName)
            }
            if (copied <= 0L) {
                tmp.delete()
                return@withContext Result.Skipped("File is empty (not downloaded yet?)")
            }

            val hash = digest.digest().joinToString("") { "%02x".format(it) }
            val existing = db.mediaDao().findByHash(hash)
            if (existing != null) {
                tmp.delete()
                if (existing.messageId == null && messageId != null) db.mediaDao().link(existing.id, messageId)
                return@withContext Result.Duplicate(existing.id)
            }

            val resolvedMime = mimeType?.takeIf { it.isNotBlank() && it != "application/octet-stream" }
                ?: guessMime(fileName)
            val dir = File(mediaRoot, type.name.lowercase()).apply { mkdirs() }
            val target = File(dir, "${hash.take(16)}_${sanitize(fileName)}")
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }

            val id = db.mediaDao().insert(
                ArchivedMedia(
                    messageId = messageId,
                    mediaType = type,
                    fileName = fileName,
                    mimeType = resolvedMime,
                    sizeBytes = copied,
                    sha256 = hash,
                    localPath = target.absolutePath,
                    sourceUri = sourceUri,
                    sourceLastModified = sourceLastModified,
                    origin = origin,
                    capturedAt = System.currentTimeMillis()
                )
            )
            if (id <= 0L) {
                target.delete()
                val dup = db.mediaDao().findByHash(hash)
                return@withContext if (dup != null) Result.Duplicate(dup.id) else Result.Failed("Database insert failed")
            }
            if (messageId == null) associate(id, type, fileName, sourceLastModified)
            Result.Imported(id)
        }
    }

    /**
     * Best-effort association of a media file with a captured message:
     *  1. Documents: exact file-name match with the name shown in the notification.
     *  2. Otherwise: nearest captured message of the same category, from 10 min before to 3 min after
     *     the file's modification time, that has no media yet.
     */
    private suspend fun associate(mediaId: Long, type: MediaType, fileName: String, fileTime: Long) {
        val dao = db.messageDao()
        val candidate = if (type == MediaType.DOCUMENT) dao.findDocumentByName(fileName) else null
        val match = candidate ?: if (fileTime > 0) {
            val categories = when (type) {
                // WhatsApp shows GIFs as videos in some versions, and voice notes as audio in others.
                MediaType.GIF -> listOf(type.category, MediaType.VIDEO.category)
                MediaType.AUDIO -> listOf(type.category, MediaType.VOICE_NOTE.category)
                MediaType.VOICE_NOTE -> listOf(type.category, MediaType.AUDIO.category)
                else -> listOf(type.category)
            }
            dao.findAssociationCandidate(
                categories = categories,
                from = fileTime - 10 * 60_000L,
                to = fileTime + 3 * 60_000L,
                timestamp = fileTime
            )
        } else null
        if (match != null) db.mediaDao().link(mediaId, match.id)
    }

    fun deleteFile(media: ArchivedMedia) {
        runCatching { File(media.localPath).delete() }
    }

    fun clearAllFiles() {
        mediaRoot.listFiles()?.forEach { it.deleteRecursively() }
        mediaRoot.mkdirs()
        tmpDir.mkdirs()
    }

    fun usedBytes(): Long = mediaRoot.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    companion object {
        fun sanitize(name: String): String =
            name.replace(Regex("""[^\w.\-]"""), "_").take(80).ifBlank { "file" }

        fun guessMime(fileName: String): String {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "opus" -> "audio/ogg"
                "webp" -> "image/webp"
                else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            }
        }

        fun typeFromMime(mime: String?, fileName: String): MediaType {
            val m = mime ?: guessMime(fileName)
            return when {
                m == "image/gif" -> MediaType.GIF
                m == "image/webp" && fileName.startsWith("STK") -> MediaType.STICKER
                m.startsWith("image/") -> MediaType.IMAGE
                m.startsWith("video/") -> MediaType.VIDEO
                fileName.startsWith("PTT") -> MediaType.VOICE_NOTE
                m.startsWith("audio/") -> MediaType.AUDIO
                else -> MediaType.DOCUMENT
            }
        }
    }
}
