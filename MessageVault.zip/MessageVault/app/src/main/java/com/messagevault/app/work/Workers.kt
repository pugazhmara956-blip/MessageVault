package com.messagevault.app.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.messagevault.app.MessageVaultApp
import com.messagevault.app.media.WhatsAppMediaScanner
import java.util.concurrent.TimeUnit

/** Copies newly downloaded WhatsApp media into the vault. */
class MediaScanWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as MessageVaultApp).container
        val settings = container.settingsRepository.current()
        if (!settings.mediaCaptureEnabled || !settings.backgroundCaptureEnabled) return Result.success()

        val full = inputData.getBoolean(KEY_FULL, false)
        val started = System.currentTimeMillis()
        val since = when {
            full -> 0L
            settings.lastMediaScanAt == 0L -> started - FIRST_SCAN_WINDOW_MS
            else -> settings.lastMediaScanAt - OVERLAP_MS
        }
        val report = WhatsAppMediaScanner.Report()
        return try {
            settings.mediaTreeUri?.let { container.mediaScanner.scanTree(it, since, report) }
            if (settings.mediaStoreScanEnabled) container.mediaScanner.scanMediaStore(since, report)
            container.settingsRepository.update { it.copy(lastMediaScanAt = started) }
            Log.i(TAG, "Scan done: $report")
            Result.success(
                workDataOf(
                    KEY_IMPORTED to report.imported,
                    KEY_EXAMINED to report.examined,
                    KEY_PROBLEMS to report.problems.take(5).joinToString("\n")
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Media scan failed", e)
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        private const val TAG = "MediaScanWorker"
        const val KEY_FULL = "full"
        const val KEY_IMPORTED = "imported"
        const val KEY_EXAMINED = "examined"
        const val KEY_PROBLEMS = "problems"
        private const val FIRST_SCAN_WINDOW_MS = 7L * 24 * 60 * 60 * 1000
        private const val OVERLAP_MS = 5L * 60 * 1000
    }
}

/** Applies automatic cleanup and the storage limit. */
class CleanupWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = try {
        val container = (applicationContext as MessageVaultApp).container
        container.archiveRepository.runMaintenance(container.settingsRepository.current())
        Result.success()
    } catch (e: Exception) {
        Log.e("CleanupWorker", "Cleanup failed", e)
        Result.retry()
    }
}

object WorkScheduler {
    private const val PERIODIC_SCAN = "media_scan_periodic"
    private const val CLEANUP = "vault_cleanup_daily"
    private const val SCAN_SOON = "media_scan_soon"
    private const val SCAN_LATER = "media_scan_later"
    const val SCAN_MANUAL = "media_scan_manual"

    fun schedulePeriodic(context: Context) {
        val wm = WorkManager.getInstance(context)
        wm.enqueueUniquePeriodicWork(
            PERIODIC_SCAN,
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<MediaScanWorker>(15, TimeUnit.MINUTES).build()
        )
        wm.enqueueUniquePeriodicWork(
            CLEANUP,
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<CleanupWorker>(1, TimeUnit.DAYS).build()
        )
    }

    /**
     * After a media message arrives, WhatsApp needs a few seconds to download the file (only if
     * auto-download is on). Scan shortly after, and once more a bit later.
     */
    fun scheduleScanSoon(context: Context) {
        val wm = WorkManager.getInstance(context)
        wm.enqueueUniqueWork(
            SCAN_SOON,
            ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<MediaScanWorker>().setInitialDelay(20, TimeUnit.SECONDS).build()
        )
        wm.enqueueUniqueWork(
            SCAN_LATER,
            ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<MediaScanWorker>().setInitialDelay(2, TimeUnit.MINUTES).build()
        )
    }

    fun scanNow(context: Context, full: Boolean) {
        WorkManager.getInstance(context).enqueueUniqueWork(
            SCAN_MANUAL,
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<MediaScanWorker>()
                .setInputData(Data.Builder().putBoolean(MediaScanWorker.KEY_FULL, full).build())
                .build()
        )
    }

    fun cleanupNow(context: Context) {
        WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<CleanupWorker>().build())
    }
}
