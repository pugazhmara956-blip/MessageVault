package com.messagevault.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.messagevault.app.data.model.MediaArchiveKind
import com.messagevault.app.data.model.MessageFilter
import com.messagevault.app.ui.components.EmptyState
import com.messagevault.app.ui.components.MediaListRow
import com.messagevault.app.ui.components.MediaThumbnail
import com.messagevault.app.ui.components.MessageRow
import com.messagevault.app.ui.components.VaultCard
import com.messagevault.app.ui.components.VaultScaffold
import com.messagevault.app.ui.viewmodel.ListEntry
import com.messagevault.app.ui.viewmodel.MediaArchiveViewModel
import com.messagevault.app.ui.viewmodel.MessageListViewModel

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

/** Screens 6, 7 and the text archive: all messages, deleted archive, text messages. */
@Composable
fun MessageListScreen(
    vm: MessageListViewModel,
    onOpenMessage: (Long) -> Unit,
    onSearch: () -> Unit,
    onBack: () -> Unit
) {
    val entries by vm.entries.collectAsState()
    VaultScaffold(
        title = vm.filter.title,
        onBack = onBack,
        actions = { IconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, contentDescription = "Search") } }
    ) { padding ->
        val list = entries
        when {
            list == null -> Box(Modifier.padding(padding)) { Loading() }
            list.isEmpty() -> Box(Modifier.padding(padding)) {
                when (vm.filter) {
                    MessageFilter.DELETED -> EmptyState(
                        Icons.Rounded.DeleteSweep,
                        "No deleted messages detected",
                        "Messages appear here when WhatsApp shows \"This message was deleted\", when a message disappears from a live notification, or when you mark one as deleted. Not every deletion can be detected — check \"All messages\" too."
                    )
                    else -> EmptyState(Icons.AutoMirrored.Rounded.Chat, "No messages yet", "Captured WhatsApp messages will appear here.")
                }
            }
            else -> LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp)
            ) {
                if (vm.filter == MessageFilter.DELETED) {
                    item {
                        VaultCard(modifier = Modifier.padding(bottom = 8.dp), container = MaterialTheme.colorScheme.surfaceContainerLow) {
                            Text(
                                "Deletion is shown only when WhatsApp exposes an indicator. \"Possibly deleted\" means the message vanished from the notification while newer ones stayed — usually a deletion, but not certain.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                items(list, key = { e ->
                    when (e) {
                        is ListEntry.Header -> e.key
                        is ListEntry.Message -> e.item.id
                    }
                }) { e ->
                    when (e) {
                        is ListEntry.Header -> Text(
                            e.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 16.dp, bottom = 8.dp, start = 4.dp)
                        )
                        is ListEntry.Message -> MessageRow(
                            e.item,
                            onClick = { onOpenMessage(e.item.id) },
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

/** Screens 8–13: image, video, audio, voice note, sticker and document archives. */
@Composable
fun MediaArchiveScreen(
    vm: MediaArchiveViewModel,
    onOpenMedia: (Long) -> Unit,
    onBack: () -> Unit
) {
    val items by vm.items.collectAsState()
    VaultScaffold(title = vm.kind.title, onBack = onBack) { padding ->
        val list = items
        when {
            list == null -> Box(Modifier.padding(padding)) { Loading() }
            list.isEmpty() -> Box(Modifier.padding(padding)) {
                EmptyState(
                    Icons.Rounded.PermMedia,
                    "No ${vm.kind.title.lowercase()} archived",
                    "Media is copied here after WhatsApp downloads it and you have connected the WhatsApp media folder (Settings → Storage). Files WhatsApp never downloaded cannot be archived."
                )
            }
            vm.kind.isGrid -> LazyVerticalGrid(
                columns = GridCells.Adaptive(110.dp),
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 32.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        "${list.size} items",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(4.dp, 4.dp, 4.dp, 10.dp)
                    )
                }
                items(list, key = { it.id }) { m ->
                    Surface(onClick = { onOpenMedia(m.id) }, shape = MaterialTheme.shapes.medium, modifier = Modifier.padding(4.dp)) {
                        MediaThumbnail(m, Modifier.fillMaxWidth().aspectRatio(1f))
                    }
                }
            }
            else -> LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp)
            ) {
                items(list, key = { it.id }) { m ->
                    MediaListRow(m) { onOpenMedia(m.id) }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

/** Convenience for the navigation layer. */
fun mediaKindOf(name: String?): MediaArchiveKind =
    runCatching { MediaArchiveKind.valueOf(name ?: "") }.getOrDefault(MediaArchiveKind.IMAGES)
