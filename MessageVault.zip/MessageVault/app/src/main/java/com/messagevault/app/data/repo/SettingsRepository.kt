package com.messagevault.app.data.repo

import com.messagevault.app.data.db.CaptureSettings
import com.messagevault.app.data.db.SettingsDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SettingsRepository(private val dao: SettingsDao) {

    private val lock = Mutex()

    val settings: Flow<CaptureSettings> = dao.observe().map { it ?: CaptureSettings() }

    suspend fun ensureDefaults() = dao.insertDefault(CaptureSettings())

    suspend fun current(): CaptureSettings = dao.get() ?: CaptureSettings()

    suspend fun update(transform: (CaptureSettings) -> CaptureSettings) = lock.withLock {
        dao.save(transform(current()).copy(id = 1))
    }
}
