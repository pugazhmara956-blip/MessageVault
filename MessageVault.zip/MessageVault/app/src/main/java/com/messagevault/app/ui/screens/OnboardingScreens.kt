package com.messagevault.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryAlert
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.messagevault.app.capture.VaultNotificationListener
import com.messagevault.app.data.db.CaptureSettings
import com.messagevault.app.media.WhatsAppMediaScanner
import com.messagevault.app.ui.components.GradientIcon
import com.messagevault.app.ui.components.SectionHeader
import com.messagevault.app.ui.components.TintedIcon
import com.messagevault.app.ui.components.VaultCard
import com.messagevault.app.ui.components.VaultLogo
import com.messagevault.app.ui.components.VaultScaffold
import com.messagevault.app.ui.components.WarningCard
import com.messagevault.app.ui.theme.VaultColors
import com.messagevault.app.ui.viewmodel.SettingsViewModel
import com.messagevault.app.util.SystemStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.os.Build

// ---- 1. Splash --------------------------------------------------------------------------------

@Composable
fun SplashScreen(settings: CaptureSettings?, onFinished: (onboardingDone: Boolean) -> Unit) {
    val scale = remember { Animatable(0.7f) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        alpha.animateTo(1f, tween(500))
    }
    val latest by rememberUpdatedState(settings)
    val finish by rememberUpdatedState(onFinished)
    LaunchedEffect(settings != null) {
        if (latest != null) {
            delay(900)
            finish(latest?.onboardingCompleted == true)
        }
    }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.scale(scale.value).alpha(alpha.value)) {
            VaultLogo(96.dp)
            Spacer(Modifier.height(20.dp))
            Text("Message Vault", style = MaterialTheme.typography.headlineMedium)
            Text("Deleted message recovery", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---- 2. Welcome -------------------------------------------------------------------------------

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        VaultLogo(72.dp)
        Spacer(Modifier.height(24.dp))
        Text("Keep a private copy of\nmessages you receive", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text(
            "Message Vault saves what WhatsApp shows in its notifications on this phone, so you can still read it later if the sender deletes it for everyone.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(28.dp))
        Feature(Icons.Rounded.NotificationsActive, "Captures notification text instantly", "Saved the moment it arrives. Nothing depends on detecting the deletion.")
        Feature(Icons.Rounded.Shield, "Stays on this phone", "No internet permission at all. Text is encrypted with a key held by the Android Keystore.")
        Feature(Icons.Rounded.PhotoLibrary, "Keeps copies of downloaded media", "Photos, videos, voice notes and documents from the WhatsApp folder you authorise.")
        Feature(Icons.Rounded.Lock, "Separate, lockable archive", "WhatsApp is never modified. View everything only inside this app.")
        Spacer(Modifier.height(12.dp))
        VaultCard(container = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Text("What it cannot do", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            Text(
                "• Messages are only captured if WhatsApp shows a notification with a preview.\n" +
                    "• Nothing is captured while that chat is open, muted, or if previews are hidden.\n" +
                    "• Media can only be kept if WhatsApp actually downloaded the file.\n" +
                    "• Messages from before you installed Message Vault cannot be recovered.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(28.dp))
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("Get started") }
    }
}

@Composable
private fun Feature(icon: ImageVector, title: String, body: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.Top) {
        GradientIcon(icon, size = 40.dp)
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---- 3. Permission setup ----------------------------------------------------------------------

@Composable
fun PermissionSetupScreen(
    vm: SettingsViewModel,
    onOpenNotificationGuide: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onFinish: () -> Unit,
    onBack: (() -> Unit)?
) {
    val context = LocalContext.current
    val sys = rememberSystemState()
    val settings by vm.settings.collectAsState()
    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.setMediaFolder(context, uri)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted.values.any { it }) vm.update { it.copy(mediaStoreScanEnabled = true) }
    }

    VaultScaffold(title = "Permission setup", onBack = onBack) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
        ) {
            Text(
                "Only what is needed is requested. Each step explains why. Only step 1 is required.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!sys.whatsappInstalled) {
                Spacer(Modifier.height(12.dp))
                WarningCard("WhatsApp not found", "WhatsApp or WhatsApp Business is not installed on this phone, so there is nothing to capture yet.")
            }

            SectionHeader("Required")
            StepCard(
                number = 1,
                icon = Icons.Rounded.Notifications,
                title = "Notification access",
                body = "Lets Message Vault read WhatsApp notifications using Android's official NotificationListenerService. This is the only way message text can be captured.",
                done = sys.listenerEnabled,
                actionLabel = if (sys.listenerEnabled) "Granted" else "Show me how",
                onAction = onOpenNotificationGuide
            )
            StepCard(
                number = 2,
                icon = Icons.Rounded.NotificationsActive,
                title = "Notification permission",
                body = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    "Not required. Android only asks for this when an app wants to POST notifications. Message Vault never shows notifications, so it does not request it."
                else "Not required on this Android version.",
                done = true,
                actionLabel = null,
                onAction = {}
            )

            SectionHeader("Optional – media")
            StepCard(
                number = 3,
                icon = Icons.Rounded.FolderOpen,
                title = "WhatsApp media folder",
                body = "Choose WhatsApp's \"Media\" folder (Android/media/com.whatsapp/WhatsApp/Media). Android then lets Message Vault read only that folder, so it can keep copies of downloaded photos, videos, voice notes and documents.",
                done = settings.mediaTreeUri != null && vm.hasTreeAccess(),
                actionLabel = if (settings.mediaTreeUri != null) "Change folder" else "Choose folder",
                onAction = { treeLauncher.launch(WhatsAppMediaScanner.suggestedInitialUri()) }
            )
            StepCard(
                number = 4,
                icon = Icons.Rounded.PhotoLibrary,
                title = "Gallery access (extra source)",
                body = "Optional backup source: reads WhatsApp images, videos and audio that appear in the phone's gallery index. Not needed if you chose the folder above.",
                done = sys.mediaPermission && settings.mediaStoreScanEnabled,
                actionLabel = if (sys.mediaPermission) (if (settings.mediaStoreScanEnabled) "Enabled" else "Enable") else "Allow",
                onAction = {
                    if (sys.mediaPermission) vm.update { it.copy(mediaStoreScanEnabled = true) }
                    else permLauncher.launch(SystemStatus.mediaStorePermissions())
                }
            )

            SectionHeader("Optional – reliability & security")
            StepCard(
                number = 5,
                icon = Icons.Rounded.BatteryAlert,
                title = if (sys.isXiaomi) "Battery & Autostart (Xiaomi / Redmi)" else "Battery optimisation",
                body = if (sys.isXiaomi)
                    "HyperOS/MIUI may stop background services. Set Battery saver to \"No restrictions\" and turn on Autostart for Message Vault so capture keeps working after restarts."
                else "Allow Message Vault to run without battery restrictions so Android does not stop the notification listener.",
                done = sys.batteryUnrestricted,
                actionLabel = "Battery settings",
                onAction = { SystemStatus.openBatterySettings(context) },
                secondaryLabel = if (sys.isXiaomi) "Autostart" else null,
                onSecondary = { SystemStatus.openXiaomiAutostart(context) }
            )
            StepCard(
                number = 6,
                icon = if (sys.biometricAvailable) Icons.Rounded.Fingerprint else Icons.Rounded.Lock,
                title = "App lock",
                body = "Protect the archive with a PIN and, if you like, your fingerprint.",
                done = settings.appLockEnabled,
                actionLabel = if (settings.appLockEnabled) "Manage" else "Set up",
                onAction = onOpenPrivacy
            )

            Spacer(Modifier.height(20.dp))
            if (!sys.listenerEnabled) {
                WarningCard(
                    "Capture will not work yet",
                    "Without notification access, Message Vault cannot see any messages. You can finish now and grant it later from Settings.",
                    critical = true
                )
                Spacer(Modifier.height(12.dp))
            }
            Button(
                onClick = {
                    vm.completeOnboarding()
                    VaultNotificationListener.requestRebindIfNeeded(context)
                    onFinish()
                },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text(if (onBack == null) "Finish setup" else "Done") }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun StepCard(
    number: Int,
    icon: ImageVector,
    title: String,
    body: String,
    done: Boolean,
    actionLabel: String?,
    onAction: () -> Unit,
    secondaryLabel: String? = null,
    onSecondary: () -> Unit = {}
) {
    VaultCard(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TintedIcon(icon, if (done) VaultColors.Teal else MaterialTheme.colorScheme.primary, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Step $number", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(title, style = MaterialTheme.typography.titleSmall)
            }
            Icon(
                if (done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                contentDescription = if (done) "Done" else "Not done",
                tint = if (done) VaultColors.Teal else MaterialTheme.colorScheme.outline
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (actionLabel != null) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onAction) { Text(actionLabel) }
                if (secondaryLabel != null) OutlinedButton(onClick = onSecondary) { Text(secondaryLabel) }
            }
        }
    }
}

// ---- 4. Notification access instructions ------------------------------------------------------

@Composable
fun NotificationAccessScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val sys = rememberSystemState()
    val connected by VaultNotificationListener.connected.collectAsState()

    VaultScaffold(title = "Notification access", onBack = onBack) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
        ) {
            VaultCard(container = if (sys.listenerEnabled) VaultColors.Teal.copy(alpha = 0.12f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(12.dp).clip(CircleShape)
                            .background(if (sys.listenerEnabled) VaultColors.Teal else MaterialTheme.colorScheme.error)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        when {
                            sys.listenerEnabled && connected -> "Access granted · listener running"
                            sys.listenerEnabled -> "Access granted · waiting for Android to start the listener"
                            else -> "Access not granted"
                        },
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }

            SectionHeader("How to turn it on")
            Instruction(1, "Tap \"Open notification access\" below.")
            Instruction(2, "Find \"Message Vault\" in the list and switch it on.")
            Instruction(3, "Confirm Android's warning. It says the app can read notifications — that is exactly how capture works, and the data never leaves your phone (the app has no internet permission).")
            Instruction(4, "Come back here. The status above turns green.")

            Spacer(Modifier.height(12.dp))
            Button(onClick = { SystemStatus.openNotificationAccess(context) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Open notification access")
            }

            SectionHeader("Switch greyed out? (\"Restricted setting\")")
            Text(
                "On Android 13 and newer, apps installed from an APK file (not from Play Store) are blocked from notification access until you allow it:",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Instruction(1, "Tap \"Open app info\" below.")
            Instruction(2, "Tap the ⋮ menu (top-right) → \"Allow restricted settings\". Confirm with your PIN/fingerprint.")
            Instruction(3, "Go back and enable notification access again.")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { SystemStatus.openAppDetails(context) }, modifier = Modifier.fillMaxWidth()) {
                Text("Open app info")
            }

            SectionHeader("Make sure WhatsApp shows previews")
            Text(
                "In WhatsApp → Settings → Notifications, keep message notifications ON and \"Show preview\" ON (if available). On the lock screen, Android may hide content, but notification access still receives it. Muted chats do not create notifications, so they cannot be captured.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { SystemStatus.openWhatsAppNotificationSettings(context) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.VisibilityOff, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Open WhatsApp notification settings")
            }

            if (sys.isXiaomi) {
                SectionHeader("Xiaomi / Redmi (HyperOS)")
                Text(
                    "HyperOS can stop the listener to save battery. Open Settings → Apps → Manage apps → Message Vault, then set Battery saver to \"No restrictions\" and turn on Autostart. Also lock the app in Recents (swipe down on its card).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { SystemStatus.openXiaomiAutostart(context) }) { Text("Autostart") }
                    FilledTonalButton(onClick = { SystemStatus.openBatterySettings(context) }) { Text("Battery") }
                }
            }
            if (sys.listenerEnabled && !connected) {
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { VaultNotificationListener.requestRebindIfNeeded(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Restart listener") }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun Instruction(n: Int, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text("$n", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}
