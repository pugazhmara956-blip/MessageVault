package com.messagevault.app.util

import android.content.Context
import android.content.Intent
import android.text.format.DateUtils
import android.widget.Toast
import androidx.core.content.FileProvider
import com.messagevault.app.data.repo.MediaItem
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Format {
    private val dateTime = SimpleDateFormat("d MMM yyyy, h:mm:ss a", Locale.getDefault())
    private val time = SimpleDateFormat("h:mm a", Locale.getDefault())
    private val day = SimpleDateFormat("EEEE, d MMM yyyy", Locale.getDefault())

    fun dateTime(ms: Long): String = if (ms <= 0) "Unknown" else synchronized(dateTime) { dateTime.format(Date(ms)) }
    fun time(ms: Long): String = synchronized(time) { time.format(Date(ms)) }

    fun dayHeader(ms: Long): String = when {
        DateUtils.isToday(ms) -> "Today"
        DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
        else -> synchronized(day) { day.format(Date(ms)) }
    }

    fun relative(ms: Long): String = if (ms <= 0) "never" else
        DateUtils.getRelativeTimeSpanString(ms, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

    private val shortDate = SimpleDateFormat("d MMM", Locale.getDefault())
    fun shortStamp(ms: Long): String = if (DateUtils.isToday(ms)) time(ms) else
        synchronized(shortDate) { shortDate.format(Date(ms)) }

    fun bytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024))
        else -> String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024))
    }

    fun startOfDay(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun initials(name: String): String {
        val parts = name.trim().split(Regex("\\s+")).filter { p -> p.firstOrNull()?.isLetterOrDigit() == true }
        return when {
            parts.isEmpty() -> "#"
            parts.size == 1 -> parts[0].take(1).uppercase()
            else -> (parts[0].take(1) + parts[1].take(1)).uppercase()
        }
    }
}

/** Opens an archived file in another app via a temporary, read-only FileProvider grant. */
fun openMediaExternally(context: Context, item: MediaItem) {
    if (!item.available) {
        Toast.makeText(context, "File is not available", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", item.file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, item.mimeType)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Open with"))
    } catch (e: Exception) {
        Toast.makeText(context, "No app can open this file type", Toast.LENGTH_LONG).show()
    }
}
