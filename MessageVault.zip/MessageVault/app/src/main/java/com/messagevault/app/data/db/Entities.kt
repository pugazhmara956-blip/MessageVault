package com.messagevault.app.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.RecoveryStatus

/** A sender or group seen in captured notifications. */
@Entity(
    tableName = "contacts",
    indices = [Index(value = ["contactKey"], unique = true)]
)
data class ContactInfo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** packageName|phone-or-name — stable identity for de-duplication. */
    val contactKey: String,
    val displayName: String,
    val phoneNumber: String?,
    val isGroup: Boolean,
    val packageName: String,
    val firstSeenAt: Long,
    val lastSeenAt: Long
)

/** A message captured from a WhatsApp notification. The text is stored encrypted. */
@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ContactInfo::class,
            parentColumns = ["id"],
            childColumns = ["contactId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["dedupeKey"], unique = true),
        Index("contactId"),
        Index("originalTimestamp"),
        Index("capturedAt"),
        Index("status"),
        Index("category"),
        Index("conversationKey")
    ]
)
data class ArchivedMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** SHA-256 over package, conversation, sender, timestamp and text. Prevents duplicates. */
    val dedupeKey: String,
    val packageName: String,
    val conversationKey: String,
    val conversationTitle: String,
    val isGroup: Boolean,
    val senderName: String,
    val senderPhone: String?,
    val contactId: Long?,
    /** AES-256-GCM ciphertext (Base64). Key is protected by the Android Keystore. */
    val encryptedText: String,
    val category: MessageCategory,
    /** e.g. a document file name shown in the notification; used to link media. */
    val attachmentHint: String?,
    val originalTimestamp: Long,
    val capturedAt: Long,
    val notificationKey: String?,
    val channelId: String?,
    val status: RecoveryStatus,
    val statusChangedAt: Long?
)

/** An independent copy of a media file, stored in app-private storage. */
@Entity(
    tableName = "media",
    foreignKeys = [
        ForeignKey(
            entity = ArchivedMessage::class,
            parentColumns = ["id"],
            childColumns = ["messageId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["sha256"], unique = true),
        Index("messageId"),
        Index("mediaType"),
        Index("sourceUri"),
        Index("capturedAt")
    ]
)
data class ArchivedMedia(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val messageId: Long?,
    val mediaType: MediaType,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    /** Content hash — the duplicate-detection key. */
    val sha256: String,
    /** Absolute path inside filesDir/vault_media. */
    val localPath: String,
    val sourceUri: String?,
    val sourceLastModified: Long,
    val origin: MediaOrigin,
    val capturedAt: Long
)

/** Single-row settings table (id = 1). */
@Entity(tableName = "capture_settings")
data class CaptureSettings(
    @PrimaryKey val id: Int = 1,
    val onboardingCompleted: Boolean = false,
    val backgroundCaptureEnabled: Boolean = true,
    val whatsappCaptureEnabled: Boolean = true,
    val whatsappBusinessCaptureEnabled: Boolean = true,
    val mediaCaptureEnabled: Boolean = true,
    val mediaStoreScanEnabled: Boolean = false,
    val appLockEnabled: Boolean = false,
    val biometricEnabled: Boolean = false,
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val secureScreen: Boolean = true,
    /** 0 = follow system, 1 = dark, 2 = light. */
    val themeMode: Int = 1,
    /** 0 = never. */
    val autoCleanupDays: Int = 0,
    /** 0 = unlimited. */
    val storageLimitMb: Int = 0,
    val mediaTreeUri: String? = null,
    val lastMediaScanAt: Long = 0,
    val lastWhatsAppNotificationAt: Long = 0,
    val lastListenerConnectedAt: Long = 0,
    val previewHiddenDetectedAt: Long = 0
)

/** Message plus its linked media (Room relation). */
data class MessageWithMedia(
    @Embedded val message: ArchivedMessage,
    @Relation(parentColumn = "id", entityColumn = "messageId")
    val media: List<ArchivedMedia>
)

/** Aggregated media statistics per type. */
data class MediaTypeStat(
    val type: MediaType,
    val count: Int,
    val bytes: Long
)

/** Message count per category. */
data class CategoryCount(
    val category: MessageCategory,
    val count: Int
)
