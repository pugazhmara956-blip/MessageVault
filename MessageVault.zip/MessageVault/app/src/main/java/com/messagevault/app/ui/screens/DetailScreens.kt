package com.messagevault.app.ui.screens

import android.media.MediaPlayer
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.messagevault.app.data.model.MediaOrigin
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.model.RecoveryStatus
import com.messagevault.app.data.repo.MediaItem
import com.messagevault.app.data.repo.MessageItem
import com.messagevault.app.ui.components.Avatar
import com.messagevault.app.ui.components.EmptyState
import com.messagevault.app.ui.components.InfoRow
import com.messagevault.app.ui.components.MediaThumbnail
import com.messagevault.app.ui.components.SectionHeader
import com.messagevault.app.ui.components.StatusBadge
import com.messagevault.app.ui.components.TintedIcon
import com.messagevault.app.ui.components.VaultCard
import com.messagevault.app.ui.components.VaultScaffold
import com.messagevault.app.ui.components.categoryIcon
import com.messagevault.app.ui.components.categoryTint
import com.messagevault.app.ui.theme.VaultColors
import com.messagevault.app.ui.viewmodel.MediaViewerViewModel
import com.messagevault.app.ui.viewmodel.MessageDetailViewModel
import com.messagevault.app.util.Format
import com.messagevault.app.util.openMediaExternally
import kotlinx.coroutines.delay

// ---- 14. Message details ----------------------------------------------------------------------

@Composable
fun MessageDetailScreen(vm: MessageDetailViewModel, onOpenMedia: (Long) -> Unit, onBack: () -> Unit) {
    val result by vm.message.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val item = result?.getOrNull()

    VaultScaffold(
        title = "Message details",
        onBack = onBack,
        actions = {
            if (item != null) {
                IconButton(onClick = {
                    clipboard.setText(AnnotatedString(item.text))
                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy text") }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, contentDescription = "Delete record") }
            }
        }
    ) { padding ->
        when {
            result == null -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            item == null -> Box(Modifier.padding(padding)) {
                EmptyState(Icons.Rounded.SearchOff, "Record not found", "This message was removed from the archive.")
            }
            else -> MessageDetailContent(
                item = item,
                modifier = Modifier.padding(padding),
                onOpenMedia = onOpenMedia,
                onToggleMark = { vm.setMarkedDeleted(item.status == RecoveryStatus.CAPTURED) }
            )
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this record?") },
            text = { Text("The saved message and its archived media copies will be permanently removed from Message Vault. WhatsApp is not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(onBack)
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun MessageDetailContent(
    item: MessageItem,
    modifier: Modifier,
    onOpenMedia: (Long) -> Unit,
    onToggleMark: () -> Unit
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            Avatar(item.senderName, isGroup = false, size = 56.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(item.senderName, style = MaterialTheme.typography.titleLarge)
                Text(
                    item.senderPhone ?: "Phone number not available",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (item.isGroup) {
                    Text("in ${item.conversationTitle}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // Recovery status
        val statusColor = when (item.status) {
            RecoveryStatus.CAPTURED -> VaultColors.Teal
            RecoveryStatus.DELETED_CONFIRMED -> MaterialTheme.colorScheme.error
            RecoveryStatus.DELETED_SUSPECTED -> VaultColors.Amber
            RecoveryStatus.MARKED_DELETED -> MaterialTheme.colorScheme.secondary
        }
        VaultCard(container = statusColor.copy(alpha = 0.10f), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Restore, contentDescription = null, tint = statusColor)
                Spacer(Modifier.width(10.dp))
                Text("Recovery status: ${item.status.label}", style = MaterialTheme.typography.titleSmall, color = statusColor)
            }
            Spacer(Modifier.height(6.dp))
            Text(item.status.description, style = MaterialTheme.typography.bodySmall)
            item.statusChangedAt?.let {
                Text("Status changed: ${Format.dateTime(it)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (item.status == RecoveryStatus.CAPTURED || item.status == RecoveryStatus.MARKED_DELETED) {
                TextButton(onClick = onToggleMark, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                    Text(if (item.status == RecoveryStatus.CAPTURED) "Mark as deleted" else "Remove deleted mark")
                }
            }
        }

        // Original message
        SectionHeader("Original message")
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
            shape = RoundedCornerShape(topStart = 6.dp, topEnd = 22.dp, bottomEnd = 22.dp, bottomStart = 22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TintedIcon(categoryIcon(item.category), categoryTint(item.category), 28.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(item.category.label, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    StatusBadge(item.status)
                }
                Spacer(Modifier.height(10.dp))
                SelectionContainer {
                    Text(item.text.ifBlank { "(no text in notification)" }, style = MaterialTheme.typography.bodyLarge)
                }
                Spacer(Modifier.height(8.dp))
                Text(Format.dateTime(item.originalTimestamp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Media
        if (item.expectsMedia || item.media.isNotEmpty()) {
            SectionHeader("Associated media")
            if (item.media.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    item.media.take(3).forEach { m ->
                        Column(Modifier.weight(1f)) {
                            Surface(onClick = { onOpenMedia(m.id) }, shape = MaterialTheme.shapes.medium) {
                                MediaThumbnail(m, Modifier.fillMaxWidth().aspectRatio(1f))
                            }
                            Text(
                                if (m.origin == MediaOrigin.NOTIFICATION_PREVIEW) "Preview" else m.type.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                    repeat(3 - item.media.take(3).size) { Spacer(Modifier.weight(1f)) }
                }
            }
            if (item.expectsMedia && !item.hasOriginalMedia) {
                Spacer(Modifier.height(10.dp))
                VaultCard(container = MaterialTheme.colorScheme.surfaceContainerHigh) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Rounded.BrokenImage, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            if (item.media.isEmpty())
                                "The original ${item.category.label.lowercase()} file is not in the archive. It is only available if WhatsApp downloaded it to the phone and you connected the WhatsApp media folder. A file that was never downloaded cannot be recovered."
                            else
                                "Only the reduced notification preview was saved. The original file was not found in the connected media folder (not downloaded, or deleted before the scan).",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        // Details
        SectionHeader("Details")
        VaultCard {
            InfoRow("Contact", item.senderName)
            InfoRow("Phone", item.senderPhone ?: "Not exposed by WhatsApp")
            InfoRow("Chat", if (item.isGroup) "Group · ${item.conversationTitle}" else "Individual chat")
            InfoRow("App", if (item.isBusiness) "WhatsApp Business" else "WhatsApp")
            InfoRow("Category", item.category.label)
            item.attachmentHint?.let { InfoRow("Attachment", it) }
            InfoRow("Sent (original)", Format.dateTime(item.originalTimestamp))
            InfoRow("Captured", Format.dateTime(item.capturedAt))
            InfoRow("Notification channel", item.channelId ?: "—")
            InfoRow("Record ID", "#${item.id}")
        }
        Spacer(Modifier.height(40.dp))
    }
}

// ---- Media viewer (images, GIFs, stickers, video, audio, documents) ---------------------------

@Composable
fun MediaViewerScreen(vm: MediaViewerViewModel, onOpenMessage: (Long) -> Unit, onBack: () -> Unit) {
    val result by vm.media.collectAsState()
    val item = result?.getOrNull()
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }

    VaultScaffold(
        title = item?.fileName ?: "Media",
        onBack = onBack,
        actions = {
            if (item != null) {
                IconButton(onClick = { openMediaExternally(context, item) }) { Icon(Icons.Rounded.OpenInNew, contentDescription = "Open with") }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, contentDescription = "Delete") }
            }
        }
    ) { padding ->
        when {
            result == null -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            item == null -> Box(Modifier.padding(padding)) { EmptyState(Icons.Rounded.SearchOff, "Media not found", "This file was removed from the archive.") }
            else -> Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                if (!item.available) {
                    EmptyState(
                        Icons.Rounded.BrokenImage,
                        "File unavailable",
                        "The archived copy of this file is missing from app storage (it may have been removed by cleanup)."
                    )
                } else {
                    when (item.type) {
                        MediaType.IMAGE, MediaType.GIF, MediaType.STICKER -> ZoomableImage(item)
                        MediaType.VIDEO -> VideoPlayer(item)
                        MediaType.VOICE_NOTE, MediaType.AUDIO -> AudioPlayer(item)
                        MediaType.DOCUMENT -> DocumentCard(item)
                    }
                }
                SectionHeader("File details")
                VaultCard {
                    InfoRow("Name", item.fileName)
                    InfoRow("Type", "${item.type.label} (${item.mimeType})")
                    InfoRow("Size", Format.bytes(item.sizeBytes))
                    InfoRow("Source", item.origin.label)
                    InfoRow("File time", Format.dateTime(item.sourceTimestamp))
                    InfoRow("Archived", Format.dateTime(item.capturedAt))
                    InfoRow("Linked message", if (item.messageId != null) "Yes" else "No match found")
                }
                if (item.messageId != null) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { onOpenMessage(item.messageId) }, modifier = Modifier.fillMaxWidth()) { Text("View linked message") }
                }
                if (item.origin == MediaOrigin.NOTIFICATION_PREVIEW) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "This is the reduced preview image WhatsApp put into its notification, not the original file.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this file?") },
            text = { Text("The archived copy will be permanently removed from Message Vault.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(onBack)
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ZoomableImage(item: MediaItem) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    Box(
        Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 560.dp).clip(MaterialTheme.shapes.large)
            .background(if (item.type == MediaType.STICKER) MaterialTheme.colorScheme.surfaceContainer else Color.Black)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 5f)
                    if (scale == 1f) {
                        offsetX = 0f; offsetY = 0f
                    } else {
                        offsetX += pan.x; offsetY += pan.y
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = item.file,
            contentDescription = item.fileName,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth().graphicsLayer {
                scaleX = scale; scaleY = scale
                translationX = offsetX; translationY = offsetY
            }
        )
    }
    Text("Pinch to zoom", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun VideoPlayer(item: MediaItem) {
    Box(Modifier.fillMaxWidth().aspectRatio(9f / 12f).clip(MaterialTheme.shapes.large).background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                VideoView(ctx).apply {
                    val controller = MediaController(ctx)
                    controller.setAnchorView(this)
                    setMediaController(controller)
                    setVideoPath(item.file.absolutePath)
                    setOnPreparedListener { mp ->
                        mp.isLooping = false
                        seekTo(1)
                    }
                    setOnErrorListener { _, _, _ ->
                        Toast.makeText(ctx, "This video format cannot be played here. Use \"Open with\".", Toast.LENGTH_LONG).show()
                        true
                    }
                }
            },
            onRelease = { it.stopPlayback() },
            modifier = Modifier.fillMaxSize()
        )
    }
    Text("Tap the video for playback controls", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun AudioPlayer(item: MediaItem) {
    val context = LocalContext.current
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableIntStateOf(0) }
    var position by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(item.file) {
        val mp = MediaPlayer()
        try {
            mp.setDataSource(item.file.absolutePath)
            mp.prepare()
            duration = mp.duration
            mp.setOnCompletionListener {
                playing = false
                position = 0
                it.seekTo(0)
            }
            player = mp
        } catch (e: Exception) {
            error = "This audio format cannot be played here. Use \"Open with\"."
            mp.release()
        }
        onDispose {
            player?.release()
            player = null
        }
    }
    LaunchedEffect(playing) {
        while (playing) {
            position = player?.currentPosition ?: 0
            delay(200)
        }
    }

    VaultCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TintedIcon(categoryIcon(item.type.category), categoryTint(item.type.category), 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (item.type == MediaType.VOICE_NOTE) "Voice note" else "Audio", style = MaterialTheme.typography.titleMedium)
                Text("${fmt(position)} / ${fmt(duration)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledIconButton(
                onClick = {
                    val p = player ?: return@FilledIconButton
                    if (playing) { p.pause(); playing = false } else { p.start(); playing = true }
                },
                enabled = player != null,
                modifier = Modifier.size(52.dp)
            ) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = if (playing) "Pause" else "Play")
            }
        }
        Spacer(Modifier.height(8.dp))
        Slider(
            value = if (duration > 0) position.toFloat() / duration else 0f,
            onValueChange = { f ->
                val target = (f * duration).toInt()
                position = target
                player?.seekTo(target)
            },
            enabled = player != null
        )
        error?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            TextButton(onClick = { openMediaExternally(context, item) }) { Text("Open with…") }
        }
    }
}

private fun fmt(ms: Int): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun DocumentCard(item: MediaItem) {
    val context = LocalContext.current
    VaultCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TintedIcon(categoryIcon(item.type.category), categoryTint(item.type.category), 56.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(item.fileName, style = MaterialTheme.typography.titleMedium)
                Text(Format.bytes(item.sizeBytes), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = { openMediaExternally(context, item) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Open document")
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Opens in a viewer app on your phone (e.g. a PDF reader) with temporary read-only access to this copy.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
