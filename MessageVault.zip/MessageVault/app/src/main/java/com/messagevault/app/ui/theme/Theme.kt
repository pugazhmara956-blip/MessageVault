package com.messagevault.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object VaultColors {
    val Indigo = Color(0xFF8AA4FF)
    val Teal = Color(0xFF5EEAD4)
    val Rose = Color(0xFFFF8FA3)
    val Amber = Color(0xFFFFC870)
    val Violet = Color(0xFFB79CFF)
    val Sky = Color(0xFF7DD3FC)
    val Lime = Color(0xFFA3E635)
    val Coral = Color(0xFFFF9E7A)

    val brand = Brush.linearGradient(listOf(Teal, Indigo))
    val danger = Brush.linearGradient(listOf(Rose, Coral))
}

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8AA4FF),
    onPrimary = Color(0xFF0B1230),
    primaryContainer = Color(0xFF243063),
    onPrimaryContainer = Color(0xFFDDE3FF),
    secondary = Color(0xFF5EEAD4),
    onSecondary = Color(0xFF00201B),
    secondaryContainer = Color(0xFF0F3D37),
    onSecondaryContainer = Color(0xFFB4F5EA),
    tertiary = Color(0xFFFFB3C6),
    error = Color(0xFFFF8FA3),
    errorContainer = Color(0xFF4A1824),
    onErrorContainer = Color(0xFFFFD9E0),
    background = Color(0xFF0A0E16),
    onBackground = Color(0xFFE4E7F0),
    surface = Color(0xFF0A0E16),
    onSurface = Color(0xFFE4E7F0),
    surfaceVariant = Color(0xFF1A2130),
    onSurfaceVariant = Color(0xFFA7AFC2),
    surfaceContainerLowest = Color(0xFF070A10),
    surfaceContainerLow = Color(0xFF10151F),
    surfaceContainer = Color(0xFF141A26),
    surfaceContainerHigh = Color(0xFF1A2130),
    surfaceContainerHighest = Color(0xFF222A3B),
    outline = Color(0xFF3A4458),
    outlineVariant = Color(0xFF262E3F)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF3A57C9),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE3FF),
    onPrimaryContainer = Color(0xFF0B1A5C),
    secondary = Color(0xFF0E8C7A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFC9F4EC),
    onSecondaryContainer = Color(0xFF00201B),
    tertiary = Color(0xFFB0365A),
    error = Color(0xFFBA1A3A),
    errorContainer = Color(0xFFFFDADF),
    onErrorContainer = Color(0xFF40000F),
    background = Color(0xFFF6F7FB),
    onBackground = Color(0xFF151A24),
    surface = Color(0xFFF6F7FB),
    onSurface = Color(0xFF151A24),
    surfaceVariant = Color(0xFFE6E9F2),
    onSurfaceVariant = Color(0xFF4A5264),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF0F2F8),
    surfaceContainer = Color(0xFFEBEEF5),
    surfaceContainerHigh = Color(0xFFE5E8F0),
    surfaceContainerHighest = Color(0xFFDFE3EC),
    outline = Color(0xFFB3BACB),
    outlineVariant = Color(0xFFD5DAE5)
)

private val VaultTypography = Typography().let { t ->
    t.copy(
        displaySmall = t.displaySmall.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
        headlineMedium = t.headlineMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp),
        headlineSmall = t.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = t.labelLarge.copy(fontWeight = FontWeight.SemiBold),
        bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp)
    )
}

private val VaultShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

/** themeMode: 0 = system, 1 = dark, 2 = light. */
@Composable
fun MessageVaultTheme(themeMode: Int = 1, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = VaultTypography,
        shapes = VaultShapes,
        content = content
    )
}
