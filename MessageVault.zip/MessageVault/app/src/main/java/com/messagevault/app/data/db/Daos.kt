package com.messagevault.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.messagevault.app.data.model.MediaType
import com.messagevault.app.data.model.MessageCategory
import com.messagevault.app.data.model.RecoveryStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(message: ArchivedMessage): Long

    @Transaction
    @Query("SELECT * FROM messages ORDER BY originalTimestamp DESC")
    fun observeAll(): Flow<List<MessageWithMedia>>

    @Transaction
    @Query("SELECT * FROM messages WHERE status != 'CAPTURED' ORDER BY originalTimestamp DESC")
    fun observeDeleted(): Flow<List<MessageWithMedia>>

    @Transaction
    @Query("SELECT * FROM messages WHERE category = :category ORDER BY originalTimestamp DESC")
    fun observeByCategory(category: MessageCategory): Flow<List<MessageWithMedia>>

    @Transaction
    @Query("SELECT * FROM messages ORDER BY capturedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<MessageWithMedia>>

    @Transaction
    @Query("SELECT * FROM messages WHERE id = :id")
    fun observeById(id: Long): Flow<MessageWithMedia?>

    @Query("SELECT COUNT(*) FROM messages")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM messages WHERE status != 'CAPTURED'")
    fun observeDeletedCount(): Flow<Int>

    @Query("SELECT category AS category, COUNT(*) AS count FROM messages GROUP BY category")
    fun observeCategoryCounts(): Flow<List<CategoryCount>>

    @Query("SELECT * FROM messages WHERE dedupeKey = :key LIMIT 1")
    suspend fun findByKey(key: String): ArchivedMessage?

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun getById(id: Long): ArchivedMessage?

    @Query("SELECT * FROM messages ORDER BY originalTimestamp ASC")
    suspend fun getAll(): List<ArchivedMessage>

    @Query(
        """SELECT * FROM messages
           WHERE packageName = :pkg AND conversationKey = :conversationKey
             AND senderName = :sender AND originalTimestamp = :timestamp
             AND status = 'CAPTURED'
           ORDER BY capturedAt DESC LIMIT 1"""
    )
    suspend fun findForPlaceholder(
        pkg: String,
        conversationKey: String,
        sender: String,
        timestamp: Long
    ): ArchivedMessage?

    @Query("UPDATE messages SET status = :status, statusChangedAt = :at WHERE id = :id")
    suspend fun updateStatus(id: Long, status: RecoveryStatus, at: Long?)

    @Query("UPDATE messages SET status = :status, statusChangedAt = :at WHERE dedupeKey = :key AND status = 'CAPTURED'")
    suspend fun markDeletedByKey(key: String, status: RecoveryStatus, at: Long): Int

    /** Nearest message of a matching category that has no real media file linked yet. */
    @Query(
        """SELECT * FROM messages
           WHERE category IN (:categories)
             AND originalTimestamp BETWEEN :from AND :to
             AND id NOT IN (SELECT messageId FROM media WHERE messageId IS NOT NULL AND origin != 'NOTIFICATION_PREVIEW')
           ORDER BY ABS(originalTimestamp - :timestamp) ASC
           LIMIT 1"""
    )
    suspend fun findAssociationCandidate(
        categories: List<MessageCategory>,
        from: Long,
        to: Long,
        timestamp: Long
    ): ArchivedMessage?

    /** Document messages expose the file name; match on it first. */
    @Query(
        """SELECT * FROM messages
           WHERE category = 'DOCUMENT' AND attachmentHint = :fileName
             AND id NOT IN (SELECT messageId FROM media WHERE messageId IS NOT NULL AND origin != 'NOTIFICATION_PREVIEW')
           ORDER BY originalTimestamp DESC
           LIMIT 1"""
    )
    suspend fun findDocumentByName(fileName: String): ArchivedMessage?

    @Query("SELECT id FROM messages WHERE capturedAt < :before")
    suspend fun idsCapturedBefore(before: Long): List<Long>

    @Query("SELECT DISTINCT senderName FROM messages ORDER BY senderName COLLATE NOCASE")
    fun observeSenders(): Flow<List<String>>

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM messages")
    suspend fun deleteAll()
}

@Dao
interface MediaDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(media: ArchivedMedia): Long

    @Query("SELECT * FROM media WHERE sha256 = :hash LIMIT 1")
    suspend fun findByHash(hash: String): ArchivedMedia?

    @Query("SELECT * FROM media WHERE sourceUri = :uri AND sourceLastModified = :lastModified AND sizeBytes = :size LIMIT 1")
    suspend fun findBySource(uri: String, lastModified: Long, size: Long): ArchivedMedia?

    @Query("SELECT * FROM media WHERE mediaType IN (:types) ORDER BY capturedAt DESC")
    fun observeByTypes(types: List<MediaType>): Flow<List<ArchivedMedia>>

    @Query("SELECT * FROM media WHERE id = :id")
    fun observeById(id: Long): Flow<ArchivedMedia?>

    @Query("SELECT * FROM media WHERE id = :id")
    suspend fun getById(id: Long): ArchivedMedia?

    @Query("SELECT * FROM media WHERE messageId = :messageId")
    suspend fun forMessage(messageId: Long): List<ArchivedMedia>

    @Query("SELECT * FROM media ORDER BY capturedAt ASC")
    suspend fun getAllOldestFirst(): List<ArchivedMedia>

    @Query("SELECT * FROM media WHERE capturedAt < :before")
    suspend fun capturedBefore(before: Long): List<ArchivedMedia>

    @Query("SELECT COUNT(*) FROM media")
    fun observeCount(): Flow<Int>

    @Query("SELECT mediaType AS type, COUNT(*) AS count, COALESCE(SUM(sizeBytes), 0) AS bytes FROM media GROUP BY mediaType")
    fun observeStats(): Flow<List<MediaTypeStat>>

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM media")
    suspend fun totalBytes(): Long

    @Query("UPDATE media SET messageId = :messageId WHERE id = :id")
    suspend fun link(id: Long, messageId: Long)

    @Query("DELETE FROM media WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM media")
    suspend fun deleteAll()
}

@Dao
interface ContactDao {

    @Query("SELECT * FROM contacts WHERE contactKey = :key LIMIT 1")
    suspend fun findByKey(key: String): ContactInfo?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(contact: ContactInfo): Long

    @Query("UPDATE contacts SET displayName = :name, phoneNumber = COALESCE(:phone, phoneNumber), lastSeenAt = :at WHERE id = :id")
    suspend fun touch(id: Long, name: String, phone: String?, at: Long)

    @Query("SELECT * FROM contacts WHERE id = :id")
    suspend fun getById(id: Long): ContactInfo?

    @Query("DELETE FROM contacts WHERE id NOT IN (SELECT contactId FROM messages WHERE contactId IS NOT NULL)")
    suspend fun deleteOrphans()

    @Query("DELETE FROM contacts")
    suspend fun deleteAll()
}

@Dao
interface SettingsDao {

    @Query("SELECT * FROM capture_settings WHERE id = 1")
    fun observe(): Flow<CaptureSettings?>

    @Query("SELECT * FROM capture_settings WHERE id = 1")
    suspend fun get(): CaptureSettings?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefault(settings: CaptureSettings)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(settings: CaptureSettings)
}
