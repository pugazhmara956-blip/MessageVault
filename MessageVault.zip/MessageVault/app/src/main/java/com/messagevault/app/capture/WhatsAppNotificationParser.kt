package com.messagevault.app.capture

import android.app.Notification
import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.os.BundleCompat
import com.messagevault.app.data.model.MessageCategory

/** One message extracted from a WhatsApp notification. */
data class ParsedMessage(
    val conversationKey: String,
    val conversationTitle: String,
    val isGroup: Boolean,
    val senderName: String,
    val senderPhone: String?,
    val text: String,
    val timestamp: Long,
    /** False when the timestamp came from the notification, not the individual message. */
    val stableTimestamp: Boolean,
    val category: MessageCategory,
    val attachmentHint: String?,
    val isDeletionPlaceholder: Boolean,
    val dataUri: Uri?,
    val dataMimeType: String?
)

data class ParsedNotification(
    val packageName: String,
    val notificationKey: String,
    val channelId: String?,
    val messages: List<ParsedMessage>,
    /** WhatsApp is posting notifications but with previews hidden ("1 new message"). */
    val previewHidden: Boolean,
    /** Big-picture image attached to the notification (photo preview), if any. */
    val picture: Bitmap?
)

/**
 * Reads only what WhatsApp itself puts into its notifications (public Android Notification APIs).
 * Nothing in WhatsApp is modified or read directly.
 */
object WhatsAppNotificationParser {

    private val countSuffix = Regex("""\s*\((\d+)\s+(new\s+)?messages?\)\s*$""", RegexOption.IGNORE_CASE)
    private val hiddenPreview = Regex("""^(\d+\s+new\s+messages?|new\s+message)$""", RegexOption.IGNORE_CASE)
    private val summaryText = Regex("""^\d+\s+messages?\s+from\s+\d+\s+chats?$""", RegexOption.IGNORE_CASE)
    private val systemText = Regex(
        """(missed|incoming|ongoing)\s+(voice|video|group)?\s*call|checking for new messages|backup in progress|backing up|restoring|downloading|calling…|ringing""",
        RegexOption.IGNORE_CASE
    )
    private val jidPhone = Regex("""^(\d{6,15})@s\.whatsapp\.net$""")
    private val phoneLike = Regex("""^\+?[\d\s\-()]{7,20}$""")

    /** Notification texts WhatsApp uses when a message is deleted for everyone (known locales). */
    private val deletionPhrases = listOf(
        "this message was deleted",
        "you deleted this message",
        "se eliminó este mensaje",
        "eliminaste este mensaje",
        "mensagem apagada",
        "esta mensagem foi apagada",
        "ce message a été supprimé",
        "diese nachricht wurde gelöscht",
        "questo messaggio è stato eliminato",
        "pesan ini telah dihapus",
        "यह मैसेज डिलीट किया गया",
        "यह मैसेज डिलीट कर दिया गया",
        "यह संदेश हटा दिया गया"
    )

    fun parse(context: Context, sbn: StatusBarNotification): ParsedNotification? {
        val notification = sbn.notification ?: return null
        val extras = notification.extras ?: return null

        // Group summaries ("5 messages from 3 chats") duplicate the child notifications.
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        // Calls, backups and other ongoing work are not messages.
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0) return null
        if (notification.category == Notification.CATEGORY_CALL ||
            notification.category == Notification.CATEGORY_PROGRESS
        ) return null

        val jid: String? = notification.shortcutId ?: sbn.tag
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val picture = extractPicture(context, notification)

        val style = runCatching {
            NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notification)
        }.getOrNull()

        val messages = mutableListOf<ParsedMessage>()
        var previewHidden = false

        if (style != null && style.messages.isNotEmpty()) {
            val isGroup = style.isGroupConversation || jid?.endsWith("@g.us") == true
            val conversationTitle = clean(
                style.conversationTitle?.toString()?.takeIf { it.isNotBlank() } ?: title
            ).ifBlank { "Unknown chat" }
            val conversationKey = jid ?: conversationTitle
            val userKey = style.user.key
            val userName = style.user.name?.toString()

            for (m in style.messages) {
                val person = m.person ?: continue // null person = the phone's owner (own reply)
                if (userKey != null && person.key == userKey) continue
                if (userKey == null && userName != null && person.name?.toString() == userName && person.key == null) continue

                val text = m.text?.toString()?.trim().orEmpty()
                if (text.isEmpty() && m.dataUri == null) continue
                if (hiddenPreview.matches(text)) {
                    previewHidden = true
                    continue
                }
                val sender = person.name?.toString()?.trim()?.takeIf { it.isNotEmpty() } ?: conversationTitle
                val phone = phoneFrom(person.uri)
                    ?: phoneFrom(person.key)
                    ?: (if (!isGroup) phoneFromJid(jid) else null)
                    ?: phoneFromName(sender)
                val (category, hint) = categorize(text, m.dataMimeType)
                messages += ParsedMessage(
                    conversationKey = conversationKey,
                    conversationTitle = if (isGroup) conversationTitle else sender,
                    isGroup = isGroup,
                    senderName = sender,
                    senderPhone = phone,
                    text = text,
                    timestamp = if (m.timestamp > 0) m.timestamp else sbn.postTime,
                    stableTimestamp = m.timestamp > 0,
                    category = category,
                    attachmentHint = hint,
                    isDeletionPlaceholder = isDeletionText(text),
                    dataUri = m.dataUri,
                    dataMimeType = m.dataMimeType
                )
            }
        } else {
            // Fallback for notifications without MessagingStyle.
            val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
            if (title.isEmpty() || text.isEmpty()) return emptyResult(sbn, notification, false, picture)
            if (title.equals("WhatsApp", true) || title.equals("WhatsApp Business", true)) {
                return emptyResult(sbn, notification, hiddenPreview.matches(text), picture)
            }
            if (summaryText.matches(text) || systemText.containsMatchIn(text)) {
                return emptyResult(sbn, notification, false, picture)
            }
            if (hiddenPreview.matches(text)) return emptyResult(sbn, notification, true, picture)

            val cleanTitle = clean(title)
            val groupSplit = cleanTitle.indexOf(": ")
            val isGroup = jid?.endsWith("@g.us") == true || groupSplit > 0
            val conversation = if (groupSplit > 0) cleanTitle.substring(0, groupSplit) else cleanTitle
            var sender = if (groupSplit > 0) cleanTitle.substring(groupSplit + 2) else cleanTitle
            var body = text
            if (isGroup && groupSplit < 0) {
                val i = text.indexOf(": ")
                if (i in 1..40) {
                    sender = text.substring(0, i)
                    body = text.substring(i + 2)
                }
            }
            val (category, hint) = categorize(body, null)
            val ts = if (notification.`when` > 0) notification.`when` else sbn.postTime
            messages += ParsedMessage(
                conversationKey = jid ?: conversation,
                conversationTitle = conversation,
                isGroup = isGroup,
                senderName = sender,
                senderPhone = (if (!isGroup) phoneFromJid(jid) else null) ?: phoneFromName(sender),
                text = body,
                timestamp = ts,
                stableTimestamp = false,
                category = category,
                attachmentHint = hint,
                isDeletionPlaceholder = isDeletionText(body),
                dataUri = null,
                dataMimeType = null
            )
        }

        return ParsedNotification(
            packageName = sbn.packageName,
            notificationKey = sbn.key,
            channelId = notification.channelId,
            messages = messages,
            previewHidden = previewHidden,
            picture = picture
        )
    }

    private fun emptyResult(
        sbn: StatusBarNotification,
        n: Notification,
        hidden: Boolean,
        picture: Bitmap?
    ) = ParsedNotification(sbn.packageName, sbn.key, n.channelId, emptyList(), hidden, picture)

    fun isDeletionText(text: String): Boolean {
        val normalized = text
            .replace(Regex("""[\p{So}\p{Cn}​-‏️]"""), "")
            .trim()
            .lowercase()
        if (normalized.length > 60) return false
        return deletionPhrases.any { normalized.contains(it) }
    }

    /** Classifies a notification line. Returns category and an attachment hint (file name / caption). */
    fun categorize(text: String, mime: String?): Pair<MessageCategory, String?> {
        if (mime != null) {
            when {
                mime.startsWith("image/gif") -> return MessageCategory.GIF to null
                mime == "image/webp" && text.contains("sticker", true) -> return MessageCategory.STICKER to null
                mime.startsWith("image/") -> return MessageCategory.IMAGE to captionOf(text, "photo")
                mime.startsWith("video/") -> return MessageCategory.VIDEO to captionOf(text, "video")
                mime.startsWith("audio/") -> return MessageCategory.AUDIO to null
            }
        }
        val t = text.trim()
        val lower = t.lowercase()
        fun starts(vararg prefixes: String) = prefixes.any { t.startsWith(it) }

        return when {
            starts("🎤") || lower.startsWith("voice message") || lower.startsWith("voice note") ->
                MessageCategory.VOICE_NOTE to null
            starts("🎵", "🎧", "🎶") || lower == "audio" ->
                MessageCategory.AUDIO to t.dropWhile { !it.isLetterOrDigit() }.trim().ifBlank { null }
            starts("📄", "📃", "📑", "📎", "📁") || lower == "document" ->
                MessageCategory.DOCUMENT to t.dropWhile { !it.isLetterOrDigit() }.trim().ifBlank { null }
            starts("👾") || lower == "gif" || lower.endsWith(" gif") ->
                MessageCategory.GIF to null
            lower == "sticker" || lower.endsWith(" sticker") || starts("💟") ->
                MessageCategory.STICKER to null
            starts("🎥", "📹", "📽") || lower == "video" ->
                MessageCategory.VIDEO to captionOf(t, "video")
            starts("📷", "📸", "🖼") || lower == "photo" ->
                MessageCategory.IMAGE to captionOf(t, "photo")
            starts("👤") || lower.startsWith("contact card") ->
                MessageCategory.CONTACT to null
            starts("📍") || lower.startsWith("location") || lower.startsWith("live location") ->
                MessageCategory.LOCATION to null
            starts("📊") || lower.startsWith("poll:") ->
                MessageCategory.POLL to null
            else -> MessageCategory.TEXT to null
        }
    }

    private fun captionOf(text: String, keyword: String): String? {
        val stripped = text.dropWhile { !it.isLetterOrDigit() }.trim()
        val caption = if (stripped.lowercase().startsWith(keyword)) stripped.drop(keyword.length).trim() else stripped
        return caption.ifBlank { null }
    }

    private fun clean(title: String): String = title.replace(countSuffix, "").trim()

    private fun phoneFromJid(jid: String?): String? =
        jid?.let { jidPhone.find(it)?.groupValues?.get(1) }?.let { "+$it" }

    private fun phoneFrom(value: String?): String? {
        if (value.isNullOrBlank()) return null
        if (value.startsWith("tel:")) return value.removePrefix("tel:").takeIf { it.isNotBlank() }
        return phoneFromJid(value)
    }

    private fun phoneFromName(name: String): String? =
        name.takeIf { phoneLike.matches(it) && it.count { c -> c.isDigit() } >= 7 }

    private fun extractPicture(context: Context, n: Notification): Bitmap? = try {
        val extras = n.extras
        BundleCompat.getParcelable(extras, Notification.EXTRA_PICTURE, Bitmap::class.java)
            ?: if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                BundleCompat.getParcelable(extras, Notification.EXTRA_PICTURE_ICON, Icon::class.java)
                    ?.loadDrawable(context)
                    ?.toBitmap()
            } else null
    } catch (e: Exception) {
        null
    }
}
