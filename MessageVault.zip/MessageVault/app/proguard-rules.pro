# Room entities and DAOs are generated/kept by the Room compiler.
# Notification listener and activities are kept via the manifest.

# Keep enum names stable: they are persisted in the database by name.
-keepclassmembers enum com.messagevault.app.data.model.** { *; }

# Keep line numbers for readable crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
